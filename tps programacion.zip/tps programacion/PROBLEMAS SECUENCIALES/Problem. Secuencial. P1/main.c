#include <stdio.h>
#include <stdlib.h>

int main()
{   float dinero, porcentaje;
    printf("ingrese el monto a invertir : ");
    scanf ("%f", &dinero);
    porcentaje = dinero*0.02;
    printf ("la cantidad de dinero ganada es de : $ %.2f ", porcentaje);

    return 0;
}
