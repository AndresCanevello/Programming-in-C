#include <stdio.h>
#include <stdlib.h>
//tp n2//
int main()
{   float ropa, descuento;
    printf ("ingrese el valor de la prenda: \n");
    scanf ("%f", &ropa);
    descuento = ropa*0.85;
    printf ("el valor de la prenda con el descuento del 15%% es de : $ %.2f\n", descuento);

    return 0;
}
