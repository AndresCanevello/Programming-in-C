#include <stdio.h>
#include <stdlib.h>
//punto n3//
int main()
{   int hombres, mujeres, alumnos;
float porcentaje1, porcentaje2;
    printf ("Ingrese la cantidad de alumnos que existan en el curso : \n");
    scanf ("%i", &alumnos);
    printf ("ingrese la cantidad de mujeres que hay en dicho alumnado : \n");
    scanf ("%i", &mujeres);
    hombres= alumnos-mujeres;
    printf ("la cantidad de hombres que hay en el curso es de : %i\n", hombres);
    porcentaje1= (float) hombres*100/alumnos;
    porcentaje2= (float) mujeres*100/alumnos;
    printf ("el porcentaje de mujeres que habra en el curso es de : %% %.2f\n", porcentaje2);
    printf ("el porcentaje de hombres que habra en el curso es de : %% %.2f", porcentaje1);
    return 0;
}
