#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arregloEdad[10];
    int arregloLegajo[10];
    char nombre[30][20];
    int vali2 = cargarArreglos (arregloEdad, arregloLegajo, nombre, 10);
    mostrarArrrays (arregloEdad, arregloLegajo, nombre, vali2);

    return 0;
}
Crear una funci�n que busque dentro del arreglo de legajos y retorne la posici�n de un determinado valor.
int devolverLegajo (int legajo[], int vali2, int pos)
{
    int i=0;
    int aux;
    if (legajo[i] == pos)
    {
        printf
    }
}
void mostrarArrrays (int edad[], int legajo[], char nombre[30][20], int vali2) //punto 5
{
    int i=0;
    while (i<vali2)
    {
        printf ("Su edad es : %i\n", edad[i]);
        printf ("Su numero de legajo es : %i\n", legajo[i]);
        printf ("El nombre es : %s \n", nombre[i]);
        i++;
    }
}
int cargarArreglos (int edad[], int legajo[], char nombre[30][20], int dim) //punto1
{
    int i=0;
    char inicio='s';
    while (i<dim && inicio =='s')
    {
        printf ("Ingrese la edad : \n");
        scanf("%i", &edad[i]);
        printf ("Ingrese su numero de legajo :\n");
        scanf ("%i", &legajo[i]);
        printf ("Ingrese el nombre correspondiente a los datos anteriores : \n");
        fflush(stdin);
        scanf("%s", nombre[i]);
        i++;
        printf ("Desea ingresar otro usuario? S/N : \n");
        fflush (stdin);
        scanf("%c", &inicio);
    }
    return i;

}
