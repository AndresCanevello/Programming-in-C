#include <stdio.h>
#include <stdlib.h>
#include <string.h>
const int coloMatriz = 20;
const int filaMatriz = 30;
void cargaArreglos (int edad[], int legajo[], char nombre[][coloMatriz], int *vali2);
void mostrarArrays (int edad[], int legajo[], char nombre[][coloMatriz], int vali2);
void insertarNombre(int edad[], int legajo[], char nombre[][coloMatriz], int vali2, char datoNombre[coloMatriz], int datoE[], int datoL[]);
void ordenXinser (int edad[], int legajo[], char nombre[][coloMatriz], int vali2);
int main()
{
   int edad [filaMatriz];
   int legajo[filaMatriz];
   char nombre [filaMatriz][coloMatriz];
   char datoNombre[filaMatriz][coloMatriz];
   int vali2;
   cargaArreglos (edad, legajo, nombre, &vali2);
    printf ("Arreglo desordenado:\n");
   mostrarArrays(edad, legajo,nombre, vali2);
    ordenXinser (edad,legajo,nombre, vali2);
    printf ("\n    Arreglo ordenado:\n");
    vali2++;
    mostrarArrays(edad, legajo,nombre, vali2);

    return 0;
}
void ordenXinser (int edad[], int legajo[], char nombre[][coloMatriz], int vali2)
{
    int i=0;
    int aux[filaMatriz];
    while (i<vali2)
    {
        strcpy (aux, nombre[i+1]);
        insertarNombre (edad, legajo, nombre, i, aux, edad[i+1], legajo[i+1]);
        i++;
    }
}
void insertarNombre(int edad[], int legajo[], char nombre[][coloMatriz], int vali2, char datoNombre[coloMatriz], int datoE[], int datoL[])
{
    int i = vali2 ;
    while (i>=0 && strcmp(nombre[i],datoNombre)>0 )
    {
        strcpy (nombre[i+1], nombre[i]);
        edad[i+1] = edad[i];
        legajo[i+1] = legajo[i];
        i--;
    }
    strcpy (nombre[i+1], datoNombre);
    edad[i+1] = datoE;
    legajo[i+1] = datoL;
}


void mostrarArraysSIN (int edad[], int legajo[], char nombre[][coloMatriz], int vali2)
{
    int i=1;
    while (i<vali2)
    {
        printf ("Edad:         |%d|\n", edad[i]);
        printf ("N� de legajo: |%d|\n", legajo[i]);
        printf ("Nombre:       |%s|\n", nombre[i]);
        i++;
    }
}
void mostrarArrays (int edad[], int legajo[], char nombre[][coloMatriz], int vali2)
{
    int i=0;
    while (i<vali2)
    {
        printf ("Edad:         |%d|\n", edad[i]);
        printf ("N� de legajo: |%d|\n", legajo[i]);
        printf ("Nombre:       |%s|\n", nombre[i]);
        i++;
    }
}
void cargaArreglos (int edad[], int legajo[], char nombre[][coloMatriz], int *vali2)
{
    char inicio = 's';
    *vali2 = 0;
    while (inicio == 's' && *vali2 < filaMatriz)
    {
        printf ("Ingrese su edad: \n");
        scanf("%d", &edad[*vali2]);
        printf ("Ingrese numero de legajo: \n");
        scanf("%d", &legajo[*vali2]);
        printf ("Ingrese su nombre: \n");
        fflush(stdin);
        scanf("%s", &nombre[*vali2]);
        printf("Perfecto. Desea ingresar otro usuario? S/N: \n");
        fflush(stdin);
        scanf("%c", &inicio);
        (*vali2) = (*vali2) + 1;
    }
}
