#include <stdio.h>
#include <stdlib.h>

int main()
{
    int*arreglo;
    int arrCargado[] = {1,2,3,4,5,6,7,8,9};
    int pares = contarPAR (arrCargado,9);
    arreglo = crearArray(arrCargado, pares);
   printf ("Arreglo cargado: \n");
   mostrarArray (arrCargado, 9);
   printf ("Arreglo de pares: \n");
   mostrarArray(arreglo, pares);
    return 0;
}
void mostrarArray(int array[], int vali2)
{
    int i=0;
    while (i<vali2)
    {
        printf ("Array en pos |%i| es: %i\n",i, array[i]);
        i++;
    }
}
int contarPAR (int array [], int vali2)
{
    int i =0 ;
    int contador=0;
    while (i<vali2)
    {
        if (array[i]%2==0)
        {
            contador++;
        }
        i++;
    }
    return contador;
}
int crearArray (int array[], int pares)
{
    int*arreglo;
    int i=0;
    int j=0;
    arreglo = malloc(pares * sizeof(int));
    while (i<9)
    {
        if (array[i]%2 == 0)
     {
         arreglo[j] = array[i];
         j++;
         printf ("Arreglo int the if %i\n", arreglo[j]);
     }
     printf ("Arreglo %i\n", arreglo[j]);
     i++;
    }
    return *arreglo;
}

