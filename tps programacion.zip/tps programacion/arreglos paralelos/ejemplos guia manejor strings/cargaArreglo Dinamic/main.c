#include <stdio.h>
#include <stdlib.h>

int main()
{
    int pelicula;
    printf  ("Ingrese que pelicula quiere ver del 1 al 4:\n ");
    scanf("%i", &pelicula);
    if (pelicula==1)
    {
        printf ("Interestelar");
    }
    else if (pelicula == 2)

    {
        printf ("toy stort");
    }
    else if (pelicula==3)
    {
        printf ("nemo");
    }
    else
    {
        printf ("Error, ingrese un numero del 1-4");
    }
    printf ("\n%i", pelicula);



    return 0;
}
/*int * arreglo (int T)
{
    int *arri;
    int i=0;
    arri = malloc (sizeof (int)*t);
    while (i<t)
    {
        printf ("Ingrese un numero en Arreglo dinamico en pos [%i] : \n");
        scanf ("%i", &arri);
    }
    return arri;
}*/
