#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
int main()
{
 int main ( ) {
    char string [ ] = "Borland International";
    int smax;
    printf ("\n\t\t FUNCION: strlen ( ):\n");
    printf ("\n char string [ ] = \"Borland International\"\n\n\n\t");


    printf (" strlen (string) = %s\n\n\n\n\t", strlen (string));


    printf (" smax = strlen (string);\n\n\n\t");
    printf (" printf(\"%%d\", smax); // Imprime: ");


    smax = strlen (string);


    printf ("%d", smax);

    return 0;
}


    return 0;
}
