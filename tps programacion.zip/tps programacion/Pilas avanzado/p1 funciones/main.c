#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
void CargarPila (Pila*);
void PasajePila (Pila*, Pila*);
int main()
{   Pila DADA2;
   Pila DADA;
   inicpila (&DADA2);
   inicpila (&DADA);
   CargarPila (&DADA);
   printf ("Ingrese los datos de la 2da Pila : \n");
   CargarPila (&DADA2);
    mostrar (&DADA);
    mostrar (&DADA2);

    PasajePila (&DADA, &DADA2);
    mostrar (&DADA2);
    return 0;
}



void PasajePila (Pila* aux,Pila* aux3)
 {

while (!pilavacia (aux))
{
    apilar (aux3, desapilar (aux));
}

}







void CargarPila (Pila* Aux2)
{
 int valores;
char inicio='s';
do
{
    printf("Ingrese un elemento en su pila \n");
    scanf ("%i", &valores  );
    apilar (Aux2, valores);
    printf ("Presione S si desea ingresar otro valor a la Pila : \n");
    fflush(stdin);
    scanf ("%c", &inicio);
}
while (inicio=='s') ;
}
