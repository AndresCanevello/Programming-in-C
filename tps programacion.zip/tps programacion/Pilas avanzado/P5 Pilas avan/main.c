#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
//Insertar un elemento en una pila ordenada de menor (tope) a mayor (base) de forma
//tal que se conserve el orden. (sin variables enteras, solo pilas)
int main()


{
    char inicio='s';
    Pila Ordenada;
    Pila Menor;
    Pila Mayor;
    Pila Aux;
    inicpila (&Aux);
    inicpila (&Ordenada);
    inicpila (&Menor);
    inicpila (&Mayor);

    apilar (&Ordenada, 2);
    apilar (&Ordenada, 4);
    apilar (&Ordenada, 5);
    apilar (&Ordenada, 7);
    apilar (&Ordenada, 9);
    apilar (&Ordenada, 12);

    mostrar (&Ordenada);


  return 0;
}
