#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
int main()
{
 Pila DADA;
 Pila Origen;
 Pila Aux;
 inicpila (&DADA);
 inicpila (&Origen);
 inicpila (&Aux);

 apilar (&DADA, 27);
 apilar (&DADA, 40);
 apilar (&DADA, 9);
 apilar (&DADA, 10);
 apilar (&DADA, 64);
 apilar (&DADA, 28);

 mostrar (&DADA);

 while (!pilavacia (&DADA))
 {
     while (!pilavacia (&Origen)&& tope(&Origen)<tope(&DADA))
     {
         apilar (&Aux, desapilar (&Origen));
     }
       apilar (&Origen, desapilar (&DADA));
    while (!pilavacia (&Aux))
    {
        apilar (&Origen, desapilar(&Aux));
    }
}
    mostrar (&Origen);
    return 0;
}
