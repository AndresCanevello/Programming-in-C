#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
int main()
{
    Pila Ordenada1;
    Pila Ordenada2;
    Pila OrdenadaFinal;
    Pila aux2;
    inicpila (&aux2);
    inicpila (&Ordenada1);
    inicpila (&Ordenada2);
    inicpila (&OrdenadaFinal);

    apilar (&Ordenada1, 1);
    apilar (&Ordenada1, 2);
    apilar (&Ordenada1, 4);
    apilar (&Ordenada1, 7);
    apilar (&Ordenada1, 10);
    apilar (&Ordenada2, 2);
    apilar (&Ordenada2, 3);
    apilar (&Ordenada2, 8);
    apilar (&Ordenada2, 9);
    mostrar (&Ordenada1);
    mostrar (&Ordenada2);

        while (!pilavacia (&Ordenada1)&&!pilavacia (&Ordenada2))
        {
            while (tope(&Ordenada1) >= (tope(&Ordenada2)))
            {
                apilar (&OrdenadaFinal, desapilar (&Ordenada1));
            }
            apilar (&Ordenada1, desapilar(&Ordenada2));
        }
        while (!pilavacia (&Ordenada1)||!pilavacia(&Ordenada2))
        {
            if (!pilavacia(&Ordenada1))
            {
                apilar (&OrdenadaFinal, desapilar (&Ordenada1));
            }
            else
            {
                apilar (&OrdenadaFinal, desapilar (&Ordenada2));
            }
        }
        mostrar (&OrdenadaFinal);
    return 0;
}
