#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
//Encontrar el menor elemento de una pila y guardarlo en otra. (sin variables enteras, solo pilas)
int main()
{
    char inicio='s';
    Pila DADA;
    Pila Menor;
    Pila Mayor;
    inicpila(&DADA);
    inicpila(&Menor);
    inicpila(&Mayor);

    while (inicio=='s')
    {
        leer (&DADA);
        printf ("Presione 'S' si desea agregar otro elemento a su Pila : \n");
        fflush(stdin);
        scanf ("%c", &inicio);
    }
    mostrar (&DADA);
    apilar (&Menor, desapilar (&DADA));
    while (!pilavacia(&DADA))
    {
        if (tope(&DADA)<=tope(&Menor))
        {
            apilar (&Mayor, desapilar (&Menor));
            apilar (&Menor, desapilar (&DADA));
        }
        else
        {
            apilar (&Mayor, desapilar (&DADA));
        }
    }
    while (!pilavacia (&Mayor))
    {
        apilar (&DADA, desapilar (&Mayor));
    }
    printf ("Su Pila es : \n");
    mostrar (&DADA);
    printf ("El elemento mas peque�o de su Pila era : \n");
    mostrar (&Menor);

    return 0;


}

