#include <stdio.h>
#include <stdlib.h>

int main()
{float camisa1, total, descuento ;
    printf ("Ingrese la cantidad de camisas que quiere llevar : \n");
    scanf ("%f", &total);
    printf ("ingrese el valor de dicha camisa : \n");
    scanf ("%f", &camisa1);
    if (total<3)
    {total=(total*camisa1)*0.9 ;
    printf ("El total de su compra sera de : $ %.2f\n", total);}
    else if (camisa1>=3)
    {total=(total*camisa1)*0.8 ;
    printf ("El total de su compra sera de : $ %.2f\n", total);}

    return 0;
}
