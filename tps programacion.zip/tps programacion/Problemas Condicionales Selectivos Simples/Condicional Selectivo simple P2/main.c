#include <stdio.h>
#include <stdlib.h>
int main()
{float carrito, descuento, total;
        printf("bienvenido al super, ingrese la cantidad de dinero que desea gastar\nsabiendo que si supera los $5.000 "
               "le daremos un descuento del %%20 : ");
        scanf("%f", &  carrito);
    if (carrito<5000)
        printf ("su total es: %f", carrito);
    else if (carrito>=5000)
        {carrito=carrito*0.8 ;
        printf ("El total de su compra es : $ %.2f", carrito);}
    return 0;
}
