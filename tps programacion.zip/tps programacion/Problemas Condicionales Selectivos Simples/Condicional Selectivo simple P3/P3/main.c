#include <stdio.h>
#include <stdlib.h>

int main()
{float horas, horasExtra, total;
        printf ("Ingrese la cantidad de horas trabajadas en su jornada semanal : \n");
        scanf ("%f", &horas);
    if (horas<=40)
     { horas= horas*300 ;
       printf ("Su sueldo sera de : $ %.2f\n", horas); }
    else if (horas>40)
     { horasExtra= horas-40 ;
        horas=(horasExtra*400)+(40*300);
     printf ("Su sueldo sera de : $ %.2f\n", horas) ; }

    return 0;
}
