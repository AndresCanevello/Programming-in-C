#include <stdio.h>
#include <stdlib.h>

int main()
{   int num1,num2;
        printf ("Ingrese 2 numeros :\n ");
        scanf ("%i %i", &num1, &num2);
if (num1<num2)
    printf ("Los numeros que ingresaste de forma ascendente se verian asi : \n%i , %i", num1, num2 );
else
    printf ("Los numeros que ingresaste de forma ascendente se verian asi : \n%i , %i", num2, num1);
    return 0;
}
