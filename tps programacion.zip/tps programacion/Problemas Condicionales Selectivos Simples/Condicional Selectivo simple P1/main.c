#include <stdio.h>
#include <stdlib.h>

int main()
{ float nota1, nota2, nota3, promedio;
        printf("Ingrese la primer nota:\n");
        scanf ("%f", &nota1);
        printf("Ingrese la segunda nota:\n");
        scanf ("%f", &nota2);
        printf("Ingrese la tercer nota:\n");
        scanf ("%f", &nota3);
    promedio= (float)(nota1+nota2+nota3)/3;
        printf ("El promedio de todas las notas es: %f\n", promedio);
    if (promedio>=7)
        printf ("Usted se encuentra dentro de los aprobados");
   else
        printf ("Usted ha desaprobado");

    return 0;
}
