#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
int main()
{
    char inicio='s', inicio2='s';
    Pila A;
    Pila B;
    Pila Aux;
    Pila Aux2;
    inicpila (&Aux2);
    inicpila (&A);
    inicpila (&B);
    inicpila (&Aux);

    while (inicio=='s')
    {
        leer (&A);
        printf ("Si desea agregar otro valor a la Pila A, presione S : ");
        fflush(stdin);
        scanf ("%c", &inicio);
    }
    while (inicio2=='s')
    {
        leer (&B);
        printf ("Si desea agregar otro valor a la Pila B, presione S : ");
        fflush(stdin);
        scanf ("%c", &inicio2);
    }

mostrar (&A);
mostrar (&B);

    while ((!pilavacia (&A)&&!pilavacia (&B))&&(tope(&A)==tope(&B)))
    {
        apilar (&Aux, desapilar (&A));
        apilar (&Aux2, desapilar (&B));

    }
    if (pilavacia (&A)&&pilavacia (&B))
        {
            printf("Las pilas son completamente iguales. ");
        } else {
        printf ("Las pilas no son completamente iguales.");
        }

    return 0;
}
