#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
int main()
{
    char inicio = 's', inicio2= 's';
    Pila Mod;
    Pila Aux;
    Pila DADA;
    Pila basura;
    inicpila (&basura);
    inicpila (&Aux);
    inicpila (&Mod);
    inicpila (&DADA);

    while (inicio=='s')
    {
        leer (&Mod);
        printf ("Si desea agregar otro valor a la Pila Mod, presione S : ");
        fflush(stdin);
        scanf ("%c", &inicio);
    }
    while (inicio2=='s')
    {
        leer (&DADA);
        printf ("Si desea agregar otro valor a la Pila DADA, presione S : ");
        fflush(stdin);
        scanf ("%c", &inicio2);
    }
    mostrar (&Mod);
    mostrar (&DADA);

    while (!pilavacia (&DADA))
    {
        if (tope(&Mod)==tope(&DADA))
        {
            apilar (&Aux, desapilar (&DADA));
        }else
        {
        apilar (&basura, desapilar (&DADA));
        }
    }
    while (!pilavacia (&basura))
    {
        apilar (&DADA, desapilar (&basura));
    }
    mostrar (&DADA);
        return 0;
    }
