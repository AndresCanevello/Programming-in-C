#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
int main()
{
    char inicio='s', inicio2='s';

    Pila Limite;
    Pila DADA;
    Pila Mayores;
    Pila Menores;
    Pila basura;
    inicpila (&basura);
    inicpila (&DADA);
    inicpila (&Limite);
    inicpila (&Mayores);
    inicpila (&Menores);

    while (inicio=='s')
    {
        leer (&Limite);
        printf ("Si desea agregar otro valor a la Pila Limite, presione S : ");
        fflush(stdin);
        scanf ("%c", &inicio);
    }
    while (inicio2=='s')
    {
        leer (&DADA);
        printf ("Si desea agregar otro valor a la Pila DADA, presione S : ");
        fflush(stdin);
        scanf ("%c", &inicio2);
    }

while (!pilavacia (&DADA)) {
    if (tope (&DADA)>=tope (&Limite)){
        apilar (&Mayores, desapilar (&DADA));}
    else{
        apilar (&Menores, desapilar (&DADA));}
    }
mostrar (&Mayores);
mostrar (&Menores);
    return 0;
}
