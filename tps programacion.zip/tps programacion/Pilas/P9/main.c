#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
int main()
{
    char inicio='s', inicio2='s';
    Pila A;
    Pila B;
    Pila aux;
    inicpila (&aux);
    inicpila (&A);
    inicpila (&B);
    while (inicio=='s')
    {
        leer (&A);
        printf ("Si desea ingresar otro valor para la pila A presione 'S' : ");
        fflush(stdin);
        scanf ("%c", &inicio);
    }
    while (inicio2=='s')
    {
        leer (&B);
        printf ("Si desea ingresar otro valor para la pila B presione 'S' : ");
        fflush(stdin);
        scanf ("%c", &inicio2);

    }

    while (!pilavacia (&A)&& !pilavacia (&B))
    {
        apilar (&aux, desapilar (&A));
        apilar (&aux, desapilar (&B));
    }
    if (pilavacia (&A)&& pilavacia (&B))
    {
        printf ("Las pilas tienen la misma cantidad de caracteres.");
    }
    else if (pilavacia (&A))
    {
        printf ("La pila A tiene menos elementos");
    }
    else
    {
        printf ("La pila B tiene menos elementos");
    }
    return 0;

}
