#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
int main()
{
    char inicio='s', inicio2='s';
    Pila DADA;
    Pila Mod;
    Pila iguales;
    Pila basura;
    Pila basura2;
    inicpila (&Mod);
    inicpila (&basura2);
    inicpila (&DADA);
    inicpila (&iguales);
    inicpila (&basura);

    while (inicio=='s')
    {
        leer (&Mod);
        printf ("Si desea agregar otro valor a la Pila Mod, presione S : ");
        fflush(stdin);
        scanf ("%c", &inicio);
    }
    while (inicio2=='s')
    {
        leer (&DADA);
        printf ("Si desea agregar otro valor a la Pila DADA, presione S : ");
        fflush(stdin);
        scanf ("%c", &inicio2);
    }
mostrar (&Mod);
mostrar (&DADA);
    while (!pilavacia (&Mod))
    {
        while (!pilavacia (&DADA))
        {
            if (tope(&Mod)==tope(&DADA))
            {
                apilar (&iguales, desapilar (&DADA));
            }
            else
            {
                apilar (&basura, desapilar (&DADA));
            }
        }
        while (!pilavacia (&basura))
        {
            apilar (&DADA, desapilar (&basura));
        }
        apilar (&basura2, desapilar (&Mod));
    }
    while (!pilavacia (&basura2))
    {
        apilar (&Mod, desapilar (&basura2));
    }
    mostrar (&DADA);
    return 0;
}
