#include <stdio.h>
#include <stdlib.h>
#include "pila.h"

int main()
{



        return 0;

}
