#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
#include <string.h>
///Saffer Paulina
int filas=10;
int columnas=50;
///-----------------------------------------------PROTOTIPADO--------------------------
//1:
void cargarArregloDia(int [], int *, int);
//2:
void copiarApila(int [], int, Pila *);
void insertar(Pila *, int );
int contarElementosPila(Pila *, int *);
//3:
void totalPrecipitaciones(int [], int, int *);
void calcularCant(int [], int, int * );
void promPrecipitaciones(int [], int, int *, int *);
//4:
void cargarNombres(char [][columnas], int, int, int *);
int buscarNombre(char [][columnas], int, int, char [], int);
void mostrarNombres(char [][columnas], int, int );
int main()
{
    //1:
    int dim=31;
    int arreglo1[dim];
    int validos1=0;
    //2:
    Pila pilita1;
    inicpila(&pilita1);
    //3:
    int sumaTotal=0;
    int cantidad=0;
    //4:
    char nombres[filas][columnas];
    char dato[10];
    int flag=0;
    int validos=0;
    //menu
    int opcion;
    char seguir='s';
    do
    {
        printf("MENU DE EJERCICIOS\n");
        printf("1-Ejercicio 1\n");
        fflush(stdin);
        scanf("%i", &opcion);

        switch(opcion)
        {
        case 1:
            cargarArregloDia(arreglo1,&validos1,dim);
            break;
        case 2:
            copiarApila( arreglo1,validos1,&pilita1);
            mostrar(&pilita1);
            contarElementosPila(&pilita1, &cantidad);
            printf("Cantidad de elementos en la pila: %i\n",cantidad);
            break;
        case 3:
//            totalPrecipitaciones(arreglo1,validos1,&sumaTotal);
//            printf("La cantidad total de precipitaciones es: %i\n", sumaTotal);
//            calcularCant( arreglo1,  validos1, &cantidad);
//            printf("Cant dias de precipitaciones: %i\n", cantidad);
            promPrecipitaciones(arreglo1,validos1,&sumaTotal,&cantidad);
            break;
        case 4:
            cargarNombres(nombres,filas,columnas, &validos);
            printf("Ingrese nombre a buscar:\n");
            fflush(stdin);
            scanf("%s", dato);
            mostrarNombres(nombres,filas,columnas);
            flag= buscarNombre( nombres, filas, columnas,dato, validos);
            if(flag==1)
            {
                printf("La persona si esta\n");
            }
            else
            {
                printf("La persona no se encuentra\n");
            }
            break;
        default:
            printf("Opcion no valida\n");
            system("PAUSE");
        }
        printf("Desea seleccionar otro ejercicio?\n");
        fflush(stdin);
        scanf("%c", &seguir);
        system("cls");
    }
    while(seguir=='s');
    return 0;
}
///Un grupo de 4 meteor�logos desea implementar un sistema en el
/// que guardaran los resultados de sus investigaciones.
///1:Deben guardar en un arreglo la cantidad de ml de agua que precipitaron ese d�a.
///Hacer una funci�n para cargar los resultados de un mes en un arreglo (Hacer el arreglo de la dimensi�n del mes m�s largo),
/// teniendo en cuenta que pueden cargar todo el mes junto, solo el resultado de un d�a, o el de varios.
/// El resultado del d�a est� expresado en un n�mero entero.
void cargarArregloDia(int arreglo1[], int *validos1, int dim)
{
    char seguir='s';
    while(seguir=='s' && *validos1<dim)
    {
        printf("entro");
        printf("Ingrese cantidad de ML de agua que precipitaron:\n");
        fflush(stdin);
        scanf("%i", &arreglo1[*validos1]);
        (*validos1)++;

        printf("Desea seguir cargando?\n");
        fflush(stdin);
        scanf("%c", &seguir);
    }
}
///2:Necesitan saber cu�ntos d�as la precipitaci�n fue mayor a 4.
///Para esto hacer una funci�n que copie aquellos valores del arreglo que fueron mayores a 4 en una pila, de manera ordenada (modularizar).
///Y otra funci�n que cuente cu�ntos datos hay finalmente en la pila
void copiarApila(int arreglo1[], int validos1, Pila *pilita1)
{
    for(int i=0; i<validos1; i++)
    {
        if(arreglo1[i]>4)
        {
            insertar(pilita1, arreglo1[i]);
        }
    }
}
void insertar(Pila *pilita1, int elemento)
{
    /// 5-3-7-6
///pos  0-1-2-3 arr
    Pila aux;///7
    inicpila(&aux);           ///   5 > 6

    while(!pilavacia(pilita1) && tope(pilita1)>elemento)
    {
        apilar(&aux, desapilar(pilita1));
    }
    apilar(pilita1, elemento);///5-6

    while(!pilavacia(&aux))///7
    {
        apilar(pilita1, desapilar(&aux));///5-6-7
    }

}
int contarElementosPila(Pila *pilita1, int *cantidad)
{
    Pila aux;
    inicpila(&aux);
    while(!pilavacia(pilita1))
    {
        apilar(&aux, desapilar(pilita1));
        (*cantidad)++;
    }
    while(!pilavacia(&aux))
    {
        apilar(pilita1, desapilar(&aux));
    }
    return *cantidad;
}
///3: Necesitan saber cu�l fue la cantidad total de precipitaci�n en el mes, y cual es el promedio de precipitaci�n diaria.
///Para esto hacer dos funciones, una que calcule el total,
/// y otra que calcule el promedio. Estas funciones deben ser de tipo void.
void totalPrecipitaciones(int arreglo1[], int validos1, int *sumaTotal)
{
    for(int i=0; i<validos1; i++)
    {
        (*sumaTotal)=(*sumaTotal)+arreglo1[i];
    }
}
void calcularCant(int arreglo1[], int validos1, int *cantidad)/// la cantidad son los dias
{
    for(int i=0; i<validos1; i++)
    {
        *cantidad=arreglo1[i];
        (*cantidad)++;
    }
}
void promPrecipitaciones(int arreglo1[], int validos1, int *sumaTotal, int *cantidad)
{
    totalPrecipitaciones(arreglo1,validos1,sumaTotal);
    printf("La cantidad total de precipitaciones es: %i\n", *sumaTotal);

    calcularCant( arreglo1,  validos1, cantidad);
    printf("Cant dias de precipitaciones: %i\n", *cantidad);

    float promedio=(float)*sumaTotal/(float)*cantidad;
    printf("El promedio es: %.2f\n", promedio);
}
///4:Por �ltimo, los investigadores desean guardar sus nombres en el informe.
///Para esto hacer una funci�n que cargue en un arreglo de palabras los nombres de los investigadores, teniendo en cuenta que pueden sumarse m�s en un futuro,
/// hasta un total de 10 nombres.
///Adem�s hacer una funci�n que recibe un nombre y nos diga si la persona est� o no en el arreglo.
void cargarNombres(char nombres[][columnas], int filas, int columnas, int *validos)
{
    char seguir='s';
    while(seguir=='s' && *validos<filas)
    {
        printf("Ingrese un nombre:\n");
        fflush(stdin);
        gets(nombres[*validos]);
        (*validos)++;

        printf("Desea cargar otro nombre?\n");
        fflush(stdin);
        scanf("%c", &seguir);
    }
}
int buscarNombre(char nombres[][columnas], int filas, int columnas, char dato[], int validos)
{
    int flag=0;
    for(int i=0; i<validos; i++)
    {
        if(strcmp(dato,nombres[i]) == 0)
        {
            flag=1;
        }
    }
    return flag;
}
void mostrarNombres(char nombres[][columnas], int filas, int columnas)
{
    for(int i=0; i<filas; i++)
    {
        puts(nombres[i]);
    }
}
