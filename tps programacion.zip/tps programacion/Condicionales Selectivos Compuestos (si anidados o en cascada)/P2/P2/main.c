#include <stdio.h>
#include <stdlib.h>

int main()
{   float num1, num2, num3 ;
    printf ("Ingrese 3 numeros : \n");
    scanf ("%f %f %f", &num1,&num2,&num3);
if (num1>num2 && num1>num3)
    printf ("El numero mas grande es : %.0f\n", num1);
else if (num2>num1 && num2>num3)
    printf ("El numero mas grande es : %.0f\n", num2);
else if (num3>num1 && num3>num2)
    printf ("El numero mas grande es : %.0f\n", num3);
    return 0;
}
