#include <stdio.h>
#include <stdlib.h>

int main()
{ float num1, num2, num3 ;
    printf ("ingrese 2 numeros : \n");
    scanf ("%f %f", &num1, &num2);
if (num1==num2)
    {num3=num1*num2 ;
    printf ("Su numero es igual a : %.2f\n", num3); }
else if (num1>num2)
     {num3= num1-num2 ;
    printf ("Su numero es igual a : %.2f\n", num3); }

else if (num1<num2)
    { num3= num1+num2 ;
    printf ("Su numero es igual a : %.2f\n", num3); }
    return 0;
}
