#include <stdio.h>
#include <stdlib.h>
void MostrarMenorMayor (int* A,int* B,int* C);
void Tablademultiplicacion(int A);
void CambioDeSigno (int *A);
//Realizar una funci�n que reciba un n�mero positivo entero por par�metro por referencia, y cambie su signo a negativo.
int main()
{

    int C;

    printf ("Ingrese un numero entero positivo o negativo y cambiaremos su sugno : \n");
    scanf ("%i", &C);
    CambioDeSigno (&C);
    printf ("Su elemento ha sido cambiado por PARAMETRO POR REFERENCIA, su num ahora es : %i\n", C);


    /*int A;
    int B;
    int C;
    char inicio='s';
    int Operate;
    printf ("Bienvenido a su calculadora!!!\n");
    do
    {
        printf ("Por favor, ingrese los numeros que desee operar : \n");
        scanf ("%i", &A);
        printf ("Ingrese su otro numero a operar : \n");
        scanf ("%i", &B);
        printf ("Sus numeros son : %i, %i \n ", A, B);

        printf ("Ingrese la operacion que desee realizar (1=+, 2=-, 3=*, 4=/):  ");
        fflush(stdin);
        scanf ("%i", &Operate);

        switch (Operate)
        {
        case (1):
            C =FuncionDeSuma (A, B);
            printf ("Su suma es = : %i\n", C);
            break;
        case (2):
            C =funcionDeResta(A, B);
            printf ("Su resta es = : %i\n", C);
            break;
        case (3):
            C =FuncionMultiplicacion (A, B);
            printf ("Su multiplicacion es = : %i\n", C);
            break;
        case (4):
            C =FuncionDivision (A, B);
            printf ("Su division es = : %i\n", C);
            break;
        default:
            printf ("Usted no ha ingresado un numero correcta, por favor, reintentar.\n");
        }
        printf ("Desea hacer otra operacion? S/N : \n");
        fflush(stdin);
        scanf ("%c", &inicio);
    }
    while (inicio=='s');*/


    /*int A;
    int B;
    int C;
    printf ("ingrese sus numeros de resta : \n");
    scanf ("%i", &A);
    scanf ("%i", &C);
    B = funcionDeResta(A, C);
    printf ("su resta es : %i", B);*/

    /* int A;
    int B;
    int C;
    printf ("ingrese sus numeros de suma : \n");
    scanf ("%i", &A);
    scanf ("%i", &C);
    B = FuncionDivision(A, C);
    printf ("su division es : %i", B);*/

    /*int A;
    int B;
    int C;
    printf ("ingrese sus numeros de suma : \n");
    scanf ("%i", &A);
    scanf ("%i", &C);
    B = FuncionDeSuma(A, C);
    printf ("su suma es : %i", B);*/


    /*int A;
     int C;
     int B;
       printf ("ingrese sus valores a multiplicar : ");
       scanf ("%i", &A);
       scanf ("%i", &C);
       B = FuncionMultiplicacion (A, C);
       printf ("El resultado de su multiplicacion es : %i", B);*/

    return 0;
}
void CambioDeSigno(int *A)
{
    *A = *A-*A-*A;
}
int funcionDeResta (int A, int B)
{
    int resultado;
    resultado = A-B;
    return resultado;
}
int FuncionDivision (int A, int B)
{
    int resultado;
    if (A>B)
    {
        resultado = A / B;
    }
    else
    {
        printf ("El numero divisor no puede ser menor que el dividendo, por favor reintente nuevamente.");
    }
    return resultado;
}
int FuncionDeSuma (int A, int B)
{
    int resultado;
    resultado = A + B;
    return resultado;
}
int FuncionMultiplicacion (int A, int B)
{
    int resultado;
    resultado = A * B;
    return resultado;
}
int SumaPositivosMenoresN (int N) //PUNTO 3
{
    int acumulador=0;
    printf ("Su numero es : %i\n", N);
    for (int i=0; N>i; i++)
    {
        acumulador= acumulador+i;

    }
    return acumulador;
}
void Tablademultiplicacion(int TAB) // PUNTO 4
{
    for (int i=1; i<11 ; i++)
    {
        int elemento ;
        elemento = TAB;
        elemento = elemento*i;
        printf ("%i x %i : %i\n", TAB, i, elemento);

        //printf ("Su tabla es : %i\n", elemento);
    }
}

void MostrarMenorMayor (int* A,int* B,int* C) //PUNTO 2
{
    if ( A>= B&& A>= C)
    {
        printf ("El numero mas grande es : %i\n", A);
    }
    else if ( B>= A&& B>= C)

    {
        printf ("El numero mas grande es : %i\n", B);
    }
    else printf ("El numero mas grande es : %i\n", C);
    if ( A< B&& A< C)
    {
        printf ("El numero menor es : %i\n", A);
    }
    else if ( B< A&& B< C)
    {
        printf ("El numero menor es : %i\n", B);
    }
    else printf ("El numero menor es : %i\n", C);
}
