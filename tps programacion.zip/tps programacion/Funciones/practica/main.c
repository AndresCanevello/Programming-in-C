#include <stdio.h>
#include <stdlib.h>

int main()
{   int num1=5;

    num1= ejemploParametroValorConRetorno(num1);
    printf ("Num1 dentro del main  %d\n", num1);
    return 0;
}
int ejemploParametroValorConRetorno(int num1)
{
    printf("Ingrese el numero uno\n");
    scanf("%d", &num1);
    printf("\nNum1 dentro de la funcion %d\n", num1);

    return num1;
}
