#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
#include <math.h>
void OrdenamientoXInsercion(Pila* A, Pila* B); //PUNTO 7
void InsertElemento (Pila* A, int elemento); //PUNTO 6
void OrdenamientoXselec (Pila* A, Pila* B); //PUNTO 5
int  MenorVal (Pila* A);
void PasarElementoOrdenado (Pila* A, Pila* B);
void CargarElemento (Pila* DADA);
void CargarElementos(Pila* DADA);
void PasarElementoPila (Pila A, Pila* B);
int SumarElementosPila (Pila A);
int CuentaDeElementosPila (Pila A);
int DivisionDePila (int Suma,int Cuenta);
int promedioTotal (Pila A);
 void pasarADecimal(Pila B);
 void CargaLimite(Pila B);
 void MostrarPila (Pila A);
int SumaUltimosDosTopes(Pila A) ;//PUNTO 8

//Desarrollar una funci�n que muestre la tabla de multiplicar de un n�mero entero recibido por par�metro.

int main()
{
    int edad =0; //con el = podes asignar valores a las variables

    printf("Ingrese su edadada\n"); //con el printf podes mostrar mensajes  por pantalla
    //scanf("%i",&edad); //con el scanf podes ingresar datos por pantalla
    printf("Edad: %i\n", edad);
    if(edad >= 18)
    {

        printf("es mayor de edad");
    }
    else
    {

        printf("Es menor a 18");
    }
    printf ("\ncanuto");







   // int promedio= promedioTotal(A);
   // printf("el promedio total es %i \n",promedio);
return 0;
}













void MostrarPila (Pila A)
   {int entero;
       while (!pilavacia (&A))
       {
           entero = desapilar (&A);
           printf ("\n%d\n", entero);
       }
   }




    /*void CargaLimite(Pila B)
    {
        char continuar='s';
        int elemento;
        Pila basura;
        inicpila(&basura);
        while(continuar=='s')
        {
            printf("Ingrese el elemento a cargar \n");
            scanf("%i",&elemento);

            if(elemento>9)
            {
                printf("Su numero es de dos digitos. No se puede cargar \n ");
                apilar(&basura,elemento);
            }
            else
            {
                apilar(B,elemento);
            }
            printf("Desea continuar ? \n");
            fflush(stdin);
            scanf("%c",&continuar);

        }
}*/
    void pasarADecimal(Pila B)
    {
        int elemento;
        int acumulador=0;
        int acumulador2=1;
       int i=0;
            /*for(i=1;!pilavacia(&B);pow(10,i++))
            {
               elemento=desapilar(&B);
               acumulador=acumulador+(elemento*i);
            }
            printf("El numero es : %i\n",acumulador);*/

        while(!pilavacia(&B))
        {
            elemento=desapilar(&B);
            acumulador=acumulador +elemento*pow(10,i);
            i++;
        }
        printf("El numero es : %i\n",acumulador);

        }
/*int promedioTotal (Pila A)
{
    int SumaPILA = SumarElementosPila(&A);

    int elementoPila = CuentaDeElementosPila(&A);

    int division= DivisionDePila(SumaPILA,elementoPila);
   return division;

}*/
int DivisionDePila (int Suma,int Cuenta)
{
    int division = Suma/Cuenta;
    return division;
}
int CuentaDeElementosPila (Pila A)
{
    int contador=0;
    Pila aux;
    inicpila(&aux);
    while (!pilavacia (&A))
    {
        apilar (&aux, desapilar (&A));
        contador++;
    }
    mostrar (&aux);
    return contador;
}

int SumarElementosPila (Pila A)
{
    int acumulador=0 ;
    while (!pilavacia (&A))
    {
        acumulador+=desapilar(&A);
    }
    return acumulador;
}


int SumaUltimosDosTopes(Pila A) //PUNTO 8
{
    int Suma;
    Suma = desapilar (&A);
    int Suma2 = desapilar (&A);
    int Resultado = Suma+Suma2;

    return Resultado;
}
void OrdenamientoXInsercion(Pila* A, Pila* B) //PUNTO 7
{

    while (!pilavacia (A))
    {
        InsertElemento(B,desapilar(A));
    }
}
void InsertElemento (Pila* B, int elemento) //PUNTO 6
{
    Pila Aux2;
    inicpila (&Aux2);
    while (!pilavacia (B)&&tope(B)>(elemento))
    {
        apilar (&Aux2, desapilar (B));
    }
    apilar (B, elemento);
    while (!pilavacia (&Aux2))
    {
        apilar (B, desapilar (&Aux2));
    }
}
void OrdenamientoXselec (Pila* A, Pila* B) //PUNTO 5
{

    while (!pilavacia (A))
    {
        int Menor = MenorVal (A);
        apilar (B, Menor);
    }
}
int  MenorVal (Pila* A) //PUNTO 4
{
    Pila aux;
    int menor;
    inicpila (&aux);
    menor = desapilar (A);
    while (!pilavacia (A))
    {
        if (tope(A)<=menor)
        {
            apilar (&aux, menor);
            menor = desapilar (A);
        }
        else
        {
            apilar (&aux, desapilar (A));
        }
    }
    while (!pilavacia (&aux))
    {
        apilar (A, desapilar (&aux));
    }
    return menor;
}
void PasarElementoOrdenado (Pila* A, Pila* B) // PUNTO 3
{
    Pila aux;
    inicpila (&aux);
    while (!pilavacia (A))
    {
        apilar (&aux, desapilar (A));
    }
    while (!pilavacia (&aux))
    {
        apilar (B, desapilar (&aux));
    }
}
void PasarElementoPila (Pila A, Pila* B) //PUNTO 2
{
    while (!pilavacia (&A))
    {
        apilar (B, desapilar (&A));
    }
}

void CargarElemento (Pila* DADA)
{
    leer (DADA);
}
void CargarElementos(Pila* DADA) //punto 1
{
    char inicio='s';
    do
    {
        int elemento;
        printf ("Ingrese un elemento:\n ");
        scanf ("%i", &elemento);
        apilar (DADA, elemento);
        printf ("Presione S si quiere ingresar otro valor : \n");
        fflush (stdin);
        scanf ("%c", &inicio);
    }
    while (inicio=='s');
}
