#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ventas=0;
    int totalCompra=0;
    int precio=0;
    int descuento=0;
    int preciototaL=0;
    int cantidad = cantCompas (&totalCompra,&precio);
    //int precioNeto = precioBruto(precio, cantidad);
    descuento = descuentoCompra(cantidad, totalCompra);
    totalCompra = totalCompra*descuento;
    factura (cantidad, precio, totalCompra, descuento, preciototaL);
    return 0;
}
void factura (int cantProduct, int precioProduc, int totalparcial, int descuento, int montoapagar)
{
    printf ("Empresa Andixon:\n");
    printf ("Cantidad productos: %i\n", cantProduct);
    printf ("Precio producto: %i\n", precioProduc);
    printf ("Total Parcial: %i\n", totalparcial);
    printf ("Descuento: -%i\n", descuento);
    printf ("Monto a pagar: %i\n",montoapagar);
}
int descuentoCompra (int totalcomp, int precioTota)
{
    if (precioTota >= 1000 && totalcomp >= 10)
    {
        precioTota*0.15;
    }
    else if (precioTota >= 2000 && totalcomp >= 25)
    {
        precioTota* 0.2;
    }
    return precioTota;
}
int precioBruto (int precio, int cantidad)
{
    int total = precio * cantidad;
    return total;
}
int cantCompas (int*totalComp, int*precio)
{
    char inicio='s';
    int i=0;
    int acumulador=0;
    while (inicio=='s')
    {
        printf ("Ingrese la cantidad de compras: \n");
        scanf("%d", totalComp);
        acumulador+=*totalComp;
        (*totalComp) = acumulador;
        i++;
        printf ("Desea ingresar otra compra? S/N: \n");
        fflush(stdin);
        scanf("%c", &inicio);
    }
    printf ("Por favor, ingrese el valor del producto: \n");
    scanf("%d", precio);
    return i;

}
