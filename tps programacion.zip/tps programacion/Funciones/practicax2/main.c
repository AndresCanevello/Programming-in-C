#include <stdio.h>
#include <stdlib.h>

int main()
{
   int numeroEntero=6;
   int *PunteroAEntero=&numeroEntero;
   *PunteroAEntero=15;
   printf ("%d", numeroEntero);
    return 0;
}
