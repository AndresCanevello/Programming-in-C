#include <stdio.h>
#include <stdlib.h>

int main()
{ float num0,num1 ;

    return 0;
}
