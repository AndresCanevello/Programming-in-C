#include <stdio.h>
#include <stdlib.h>

int main()
{   int positivo, num,i=1;

        printf ("Ingrese un numero negativo y se mostrara positivo : \n");

 for (i=1 ; i<15 ; i++)
    {
    scanf ("%i", &num);
    if (num<0)   {
    positivo=(-num); printf ("Su numero es : %i", positivo);}
    else  {
    printf ("Su numero ya es positivo.");}
}
}
