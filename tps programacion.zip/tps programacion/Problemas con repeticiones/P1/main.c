#include <stdio.h>
#include <stdlib.h>

int main()
{ float nota1,nota2,nota3,nota4,nota5,nota6,nota7, promedio ;
        printf ("Ingrese las notas a promediar : \n");
        scanf ("%f %f %f %f %f %f %f", &nota1,&nota2,&nota3,&nota4,&nota5,&nota6,&nota7);
    promedio=(nota1+nota2+nota3+nota4+nota5+nota6+nota7)/7 ;
    printf ("El promedio es : %.1f\n", promedio);


    return 0;
}
