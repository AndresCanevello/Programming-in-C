#include <stdio.h>
#include <stdlib.h>

int main()
{ float i=0, postivios, num1,num2,num3,num4,num5,num6,num7,num8,num9,num10 ;
    printf ("Ingrese 10 numeros : \n ");
    scanf ("%f %f %f %f %f %f %f %f %f %f",&num1,&num2,&num3,&num4,&num5,&num6,&num7,&num8,&num9,&num10);
if (num1>=0)
    printf (" El %.0f se encuentra dentro de los numeros positivos.\n", num1);
if (num2>=0)
    printf (" El %.0f se encuentra dentro de los numeros positivos.\n", num2);
if (num3>=0)
    printf (" El %.0f se encuentra dentro de los numeros positivos.\n", num3);
if (num4>=0)
    printf (" El %.0f se encuentra dentro de los numeros positivos.\n", num4);
if (num5>=0)
    printf (" El %.0f se encuentra dentro de los numeros positivos.\n", num5);
if (num6>=0)
    printf (" El %.0f se encuentra dentro de los numeros positivos.\n", num6);
if (num7>=0)
    printf (" El %.0f se encuentra dentro de los numeros positivos.\n", num7);
if (num8>=0)
    printf (" El %.0f se encuentra dentro de los numeros positivos.\n", num8);
if (num9>=0)
    printf (" El %.0f se encuentra dentro de los numeros positivos.\n", num9);
if (num10>=0)
    printf (" El %.0f se encuentra dentro de los numeros positivos.\n", num10);

return 0;
}

