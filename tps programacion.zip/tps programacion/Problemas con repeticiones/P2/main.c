#include <stdio.h>
#include <stdlib.h>

int main()
{ float i, cubo, cuarta ;
    for (i=0; i<10; i++){
    cubo= i*i*i ;
    cuarta= i*i*i*i ;
    printf ("el cubo del numero %.0f es : %.0f\n", i, cubo);
    printf ("la cuarta del numero %.0f es : %.0f\n", i, cuarta);

}
    return 0;
}
