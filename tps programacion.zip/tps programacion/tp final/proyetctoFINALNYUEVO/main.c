#include <stdio.h>
#include <stdlib.h>
#include "astronauta.h"
#include "misiones.h"
#define nave "nombreNave"
int main()
{
   // cargaAstronauta(nombre);
    cargaMisionNueva(nave,42);
    mostrarMision(nave);
}



