#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int ID;
    char TipoNave[15];
    int CantVuelos;
    int HorasVuelo;
    char Estado[30];
} stNaves;
