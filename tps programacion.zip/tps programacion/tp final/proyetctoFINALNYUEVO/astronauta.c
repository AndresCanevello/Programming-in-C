#include <stdio.h>
#include <stdlib.h>
#include "astronauta.h"
void cargaAstronauta(char nombre[])
{
    printf("ASD \n");
    FILE * archi = fopen("nombre","wb");

    astronauta aux;
    char inicio='s';
    int i=0;
    if (archi!=NULL)
    {
        while (inicio=='s')
        {

             //scanf("%i",&aux.id);
             /*printf ("Ingrese nombre:\n");
             fflush(stdin);
             scanf("%s", &aux.nombre);
             printf ("Ingrese el apellido:\n")
             fflush(stdin);
             scanf("%s", &aux.apellido);
             printf ("Ingrese apodo:\n");
             fflush(stdin);
             scanf("%s", &aux.apodo);
             printf ("Ingrese edad:\n");
             scanf("%i", &aux.edad);
             printf ("Ingrese nacionalidad:\n");
             fflush(stdin);
             scanf("%s", &aux.nacionalidad);
             printf ("Ingrese especialidad:\n");
             fflush(stdin);
             scanf("%s", &aux.especialidad);
             printf ("Ingrese horas de vuelo:\n");
             scanf("%i", &aux.horas_vuelo);
             printf ("Ingrese la cantidad de misiones espaciales realizadas:\n");
             scanf("%i", &aux.misiones_realizadas);
             printf ("Ingrese horas en estacion espacial:\n");
             scanf("%i", &aux.horas_en_estacion);
             printf ("Estado en que se encuentra(1-ACTIVO,2-RETIRADO): \n");
             scanf("%i", &aux.estado);*/




             fwrite(&aux, sizeof(astronauta),1,archi);
             printf("continuar \n");
             fflush(stdin);
             scanf("%c",&inicio);
            }
            fclose(archi);
    }
}

