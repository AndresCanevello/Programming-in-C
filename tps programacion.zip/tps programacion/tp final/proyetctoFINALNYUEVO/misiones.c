#include <stdio.h>
#include <stdlib.h>
#include "misiones.h"

void mostrarMision (char nombre[])
{
    FILE*archi = fopen(nombre,"rb");
    misiones jaguar;
    if(archi!=NULL)
    {
        while (!feof(archi))
        {
            fread(&jaguar,sizeof(misiones),1,archi);
            if (!feof(archi))
            {
                puts("------------------------------------------");
                printf("ID: %i\n",jaguar.id);
                printf("ID NAVE:%i\n",jaguar.id_nave);
                printf("Estado de la MISION: %i|  ",jaguar.estado);
                if (jaguar.estado==1)
                {
                    printf("Listo.\n");
                }
                else if(jaguar.estado==2)
                {
                    printf("En vuelo.\n");
                }
                else if(jaguar.estado==3)
                {
                    printf("Retornada.\n");
                }else if(jaguar.estado==4)
                {
                    printf("Cancelada.\n");
                }
                else if(jaguar.estado==5)
                {
                    printf("Fallida.\n");
                }
                printf ("Destino : %s\n",jaguar.destino);
                printf("Cargamento: %s\n",jaguar.cargamento);
                printf ("Detalle de la mision:%s\n", jaguar.detalle_d_mision);
                    printf ("ID tripulantes: %d");
            }
        }
    }
}
void cargaMisionNueva (char nombre[],int idnave)
{
    FILE * archi ;
    archi = fopen(nombre, "wb");
    char inicio='s';
    misiones numeroI;
    int id=300;
    int aux;

    if (archi != NULL)
    {
        while (inicio=='s')
        {

            numeroI.id = id;
            id++;
            printf("ID:|%i|\n", numeroI.id);
            printf ("ID de la NAVE: |%i|\n ",idnave);
            printf ("Estado de la mision:\n");
            printf ("|(1_Listo, 2_En vuelo, 3_Retornada, 4_Cancelada, 5_Fallida)|\n");
            scanf("%i",&numeroI.estado);
            printf ("             Ingrese el destino :\n");
            fflush(stdin);
            scanf("%s", &numeroI.destino);
            printf ("           Ingrese el cargamento:\n");
            fflush(stdin);
            scanf("%s", &numeroI.cargamento);
            printf ("Ingrese los detalles de la mision:\n");
            fflush(stdin);
            gets(numeroI.detalle_d_mision);
            fwrite(&numeroI,sizeof(misiones),1,archi);
            printf ("Desea ingresar otro usuario? S/N:\n");
            fflush(stdin);
            scanf("%c", &inicio);
        }
        fclose(archi);
    }
}
