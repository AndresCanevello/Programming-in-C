#include <stdio.h>
#include <stdlib.h>


typedef struct
{
    int id;
    char nombre[30];
    char apellido[30];
    char apodo[20];
    int edad;
    char nacionalidad[30];
    char especialidad[20];
    int horas_vuelo;
    int misiones_realizadas;
    int horas_en_estacion;
    int estado;
}astronauta;

void cargaAstronauta(char []);
void comprobarID(astronauta *aux,char []);
