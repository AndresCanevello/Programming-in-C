#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int id;
    int id_nave;
    int estado;
    char destino[30];
    char cargamento[100];
    int id_tripu[6];
    char detalle_d_mision[100];
}misiones;
void cargaMisionNueva (char nombre[],int idnave);
void mostrarMision (char nombre[]);
