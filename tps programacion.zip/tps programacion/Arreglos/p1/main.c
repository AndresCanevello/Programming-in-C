#include <stdio.h>
#include <stdlib.h>
//#define i 3.14
int main()
{
    printf("Hello world!\n");
    const int i =7;
    scanf("%i", &i);
    printf ("%i", i);
    return 0;
}
