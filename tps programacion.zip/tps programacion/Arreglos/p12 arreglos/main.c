#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arreglo[10];
    int arregloco[15];
    int arreglito[30];
    printf ("Cargar su arreglo C :");
     int validos1 = cargarArreglo (arreglo, 10);
     printf ("Cargar su arreglo B : ");
    int validos = cargarArreglo (arregloco, 15);

    int real = validos1 + validos;
    colicionDeArreglos (arreglo, arregloco, arreglito, validos1, validos);
    mostrarArreglo (arreglito, real );
    return 0;
}
void colicionDeArreglos (int arreglo[], int arregloco[], int arreglito[], int vali1, int vali2)
{
    int i=0;
    int b=0;
    int c=0;
    int suma = vali1 + vali2;
    while ( (i<suma) && (c<vali1) && (b<vali2))
    {
        if (arreglo[c]<arregloco[b])
        {
            arreglito[i] = arreglo [c];
            i++;
            c++;
        }
        else
        {
            arreglito [i] = arregloco [b];
            i++;
            b++;
        }
    }
    if (c>vali1-1)
    {
        printf ("Su arreglo C se quedo sin elemento.");
    }
    else
    {
    printf("su arreglo B se quedo sin elemento.");
    }

    while (i<suma)
    {
        if (c>vali1-1)
        {
        arreglito[i] = arregloco[b] ;
        i++;
        b++;
        }
        else
        {
        arreglito[i] = arreglo[c];
        i++;
        c++;
        }
    }


}
void mostrarArreglo (int arreglo[], int vali2)
{
    int i=0;
    while (i<vali2)
    {
        printf ("Su arreglo en posicion [%i] es :  %i\n",i , arreglo[i]);
        i++;
    }
}
int cargarArreglo (int arreglo[], int dim)
{
    int i=0;
    char inicio='s';
    while (i<dim&&inicio=='s')
    {
        printf ("Ingrese en su arreglo en la posicion %i :  \n", i);
        scanf ("%i", &arreglo[i]);
        printf ("Desea cargar otro elemento? S/N  : ");
        fflush (stdin);
        scanf("%c", &inicio);
        i++;
   }
   return i;
}
