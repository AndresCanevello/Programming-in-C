#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
int cargarArregloChAR (char arreglo[], int dimension);
int sumaArreglo (int arreglo[], int vali2);
void pasarArregloAPila (int arreglo[], int vali2, Pila* poroto);
void mostrarArreglo (int arreglo[], int vali2 );
int cargarArreglo (int arreglo[], int dimension);
int sumaArregloFloat (float arreglo[], float vali2);
void insertar (char arreglo[],int vali2, char dato );
void ordenamientoXinsercion (char arreglo[], int vali2, char dato);
void arregloCapicua (int arreglo[], int vali2);
//Ordenar un arreglo seg�n los siguientes m�todos:
//Selecci�n
//Inserci�n

int main()
{
    char Arreglo[10];
    char elemento;
    int Validos = cargarArreglo(Arreglo, 10);
    mostrarArreglo (Arreglo, Validos);
    scanf("%i",&elemento);
    insertar(Arreglo, Validos, elemento);
    mostrarArreglo (Arreglo, Validos);

    return 0;
}
void ordenamientoXselec (int arreglo[], int vali2)
{
    int aux2;
    int i=0;
    while (i < vali2)
    {
        int menor = encontrarMenor(arreglo, vali2, i);

        aux2=arreglo[i];
        arreglo[i] = arreglo[menor];
        arreglo[menor] = aux2;
        i++;
    }
}
int encontrarMenor (int arreglo[], int vali2, int posInicial )
{
    int menor=posInicial;
    int i=posInicial++;
    while (i<vali2)
    {
        if (arreglo [i] < arreglo[menor])
        {
            menor= i ;
        }
        i++;
    }
    return menor;
}




void dadorArreglo (int arreglo[], int vali2) //punto 10
{
    int aux2;
    int b=vali2-1;
    vali2 = vali2/2;
    for (int i=0; i<vali2; i++)
    {
        aux2 = arreglo[i];
        arreglo[i] = arreglo[b];
        arreglo[b] = aux2;
        b--;
    }
}
void arregloCapicua (int arreglo[], int vali2) //punto 9
{
    int i=0;
    int arregloAux[10];
    int b = vali2-1;
    while (i<vali2)
    {
        arregloAux[i] = arreglo[b];
        i++;
        b--;
    }
    i=0;
    while (arreglo[i]==arregloAux[i]&& i<vali2)
    {
        i++;
    }
    if (i==vali2)
    {
        printf ("El arreglo es capicua.");
    }
    else
    {
        printf ("El arreglo NO es capicua.");
    }
}
void ordenamientoXinsercion (char arreglo[], int vali2, char dato)
{
    int i=0;
    while (i<vali2-1)
    {
        insertar (arreglo, i, dato);
        i++;
    }
}
void insertar (char arreglo[],int vali2, char dato )
{
    int i = vali2;
    while (i>=0 && dato< arreglo[i])
    {
        arreglo[i+1]= arreglo[i];
        i--;
    }
    arreglo[i+1]= dato;
}

void encontrarElemento (char Arreglo[], int vali2, char elemento) //PUNTO 6
{
    int i;
    while (i<vali2&&elemento !=Arreglo[i])
    {
        i++;
    }
    if (Arreglo[i]==elemento)
    {
        printf ("Su elemento se encuentra dentro del arreglo en la posicion [%i]. %c\n", i, elemento);
    }
    else if (i>=vali2)
    {
        printf ("Su elemento no se encuentra dentro del arreglo. \n");
    }

}
int sumaArregloFloat (float arreglo[], float vali2) //PUNTO 5
{
    int acumulador=0;
    for (int i=0; i<vali2; i++)
    {
        acumulador+=arreglo[i];
    }
    return acumulador;
}
void mostrarArregloFloat (float arreglo[], float vali2 ) //PUNTO 5
{
    int i=0;
    for ( i=0; i<vali2; i++)
    {
        printf ("Su arreglo en la posicion %i es : %2.f\n\n",i, arreglo[i] );
    }
}
int cargarArreglo (int arreglo[], int dimension) //PUNTO 5
{
    int contador=0;
    char continuar='s';
    for (int i=0; i<dimension&&continuar=='s'; i++)
    {
        printf ("Ingrese un valor entero en su arreglo en la posicion [%i] : \n ", i);
        scanf ("%i", &arreglo[i]);
        printf ("Desea ingresar otro valor? Ingrese S/N : \n");
        fflush(stdin);
        scanf ("%c",&continuar);
        contador++ ;
    }
    return contador;
}
void pasarArregloAPila (int arreglo[], int vali2, Pila* poroto) //PUNTO 4
{

    for (int i=0; i<vali2; i++)
    {
        apilar (poroto, arreglo[i]);
    }
}
int sumaArreglo (int arreglo[], int vali2) //PUNTO 2
{
    int acumulador=0;
    for (int i=0; i<vali2; i++)
    {
        acumulador+= arreglo[i];
    }
    return acumulador;
}
void mostrarArreglo (int arreglo[], int vali2)
{
    int i=0;
    for ( i=0; i<vali2; i++)
    {
        printf ("Su arreglo en la posicion %i es : %i\n\n",i, arreglo[i] );
    }
}
int cargarArregloChAR (char arreglo[], int dimension)
{
    int i;
    int contador=0;
    char continuar='s';
    while (continuar=='s'&&i<dimension)
    {
        printf ("Ingrese un valor entero en su arreglo en la posicion [%i] : \n ", i);
        fflush(stdin);
        scanf ("%c", &arreglo[i]);
        printf ("Desea ingresar otro valor? Ingrese S/N : \n");
        fflush(stdin);
        scanf ("%c",&continuar);
        i++;

    }
    return i;
}

