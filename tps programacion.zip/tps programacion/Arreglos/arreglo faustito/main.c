#include <stdio.h>
#include <stdlib.h>
void mostrarArreglo (int arreglo[], int vali2);
int cargarArreglo (int arreglo[], int dimension); //PUNTO 5
int encontrarMenor (int arr[],int vali2,int posinicial);
void ordenamientoseleccion (int arr[],int vali2);

int main()
{
    int arreglo[10];
    int validos = cargarArreglo (arreglo,10);
    ordenamientoseleccion (arreglo,validos);
    mostrarArreglo (arreglo, validos);

    return 0;
}
void mostrarArreglo (int arreglo[], int vali2)
{
    int i=0;
    for ( i=0; i<vali2; i++)
    {
        printf ("Su arreglo en la posicion %i es : %i\n\n",i, arreglo[i] );
    }
}
int cargarArreglo (int arreglo[], int dimension) //PUNTO 5
{
    int contador=0;
    char continuar='s';
    for (int i=0; i<dimension&&continuar=='s'; i++)
    {
        printf ("Ingrese un valor entero en su arreglo en la posicion [%i] : \n ", i);
        scanf ("%i", &arreglo[i]);
        printf ("Desea ingresar otro valor? Ingrese S/N : \n");
        fflush(stdin);
        scanf ("%c",&continuar);
        contador++ ;
    }
    return contador;
}
    int encontrarMenor (int arr[],int vali2,int posinicial)
    {
        int menor = posinicial;
        int i = posinicial ++;
        while (i<vali2)
        {
            if(arr[i]<arr[menor])
            {
                menor= i;
            }
            i++;
        }
        return menor;
    }
    void ordenamientoseleccion (int arr[],int vali2)
    {
    int i = 0;
    int aux;
    while(i<vali2)
    {
       int menor = encontrarMenor (arr,vali2,i);
        aux = arr[i];
        arr[i]=arr[menor];
        arr[menor]=aux;
        i++;
    }
    }

