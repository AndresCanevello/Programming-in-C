#include <stdio.h>
#include <stdlib.h>
#include "pila.h"
int main()
{
    int arreglo[50]={0};
    int vali2 = cargarArreglo(arreglo, 50); //PUNTO 1
    mostrarArreglo (arreglo, vali2);
    int validos;
    Pila pilita;
    inicpila(&pilita);
    printf ("Ahora, cargaremos la Pila que se pasara a su arreglo \n");
    cargarPila(&pilita);
    printf ("Su pila sin la funcion de mostrar es : \n");
    mostrarPila (&pilita);
    //int DatosPila = cargarPila(&pilita);
    int ParOimpar = copiaPilaAarreglo (pilita, arreglo, &validos);
    if (ParOimpar==1)
    {
        printf ("El numero de elementos pasados al arreglo es par. %i\n", ParOimpar);
    }
    else
    {
    printf ("El numero de elementos pasados al arreglo es impar . %i\n", ParOimpar);
    }
    printf ("Su arreglo con numeros mayores que 96 y menores a 123 es : \n");
    mostrarArreglo(arreglo, validos);


    printf ("Por ultimo, a continuacion\ningrese un dato a insertar en las pilas.\nSi es multiplo de 10 cargaremos en Pila A.\nSi es par y distinto de 10 cargaremos en pila B.\n Por ultimo si es impar cargaremos en Pila C.\n");
    Pila a;
    Pila b;
    Pila c;
    inicpila(&b);
    inicpila(&c);
    inicpila(&a);
    int DATO;
    cargarPilaEspec (a,&b,&c,DATO);
    printf ("Su pila con numeros impares es : \n");
    mostrar (&c);
    printf ("Su pila de pares y distintos de 10 es : \n");
    mostrar(&b);



    return 0;
}

void cargarPilaEspec (Pila a, Pila*b, Pila*c, int dato)
{
    char inicio='s';
    while (inicio=='s')
    {
        scanf("%i", &dato);
    if (dato%10==0)
    {
        apilar (&a, dato);
    }
    else if (dato%2==0&&dato%10!=0)
    {
        apilar (b, dato);
    }
    else
    {
     apilar (c, dato);
    }
    printf ("Desea ingresar otro dato? S/N:  \n");
    fflush(stdin);
    scanf("%c", &inicio);
    }
    printf ("Su pila de multiplos de 10 es : \n");
    mostrar(&a);
}
int copiaPilaAarreglo (Pila pilita, int arreglo[],int *aux2)
{
    int i=0;
    Pila aux;
    inicpila(&aux);
    while (!pilavacia(&pilita))
    {
        if(tope(&pilita)>96 && tope(&pilita)<123)
        {
           arreglo[i] = desapilar(&pilita);
           i++;
        }
        else
        {
            apilar (&aux, desapilar(&pilita));

        }
    }
    *aux2 = i;
    if (i%2==0)
    {
        i=1;
    }
    else {i=0;}
    return i;
}
int cargarPila(Pila*pilita)
{
    char inicio='s';
    int acumulador=0;
    int i=0;
    while (inicio=='s')
    {
        printf ("Ingrese los datos en su pila : \n");
        scanf("%i", &acumulador);
        apilar(pilita, acumulador);
        printf("Desea ingresar otro dato en su pila? S/N : \n");
        fflush(stdin);
        scanf("%c", &inicio);
        i++;
    }
    return i;
}
void mostrarPila (Pila pilita)
{
    int aux;
    printf ("TOPE");
    while (!pilavacia(&pilita))
    {
        aux = desapilar(&pilita);
        printf ("  %i ", aux);
    }
    printf("BASE\n");
}
void mostrarArreglo(int arreglo[], int vali2)
{
    int i=0;
    while (i<vali2)
    {
        printf ("Arreglo en pos [%i] =  %i\n",i,arreglo[i]);
        i++;
    }
}
int cargarArreglo (int arreglo[], int dim)
{
    int i=0;
    char inicio='s';
    while (i<dim && inicio == 's')
    {
        printf ("Ingrese el dato que desea cargar en su arrelgo en pos %i : \n",i);
        scanf("%i",&arreglo[i]);
        printf("Desea ingresar otro dato? S/N:  \n");
        fflush(stdin);
        scanf("%c", &inicio);
        i++;
    }
    return i;
}
