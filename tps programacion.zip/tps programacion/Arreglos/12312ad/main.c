#include <stdio.h>
#include <stdlib.h>
//Se necesita sumar dos n�meros le�dos desde el teclado (los ingresa el usuario) y mostrar el resultado por pantalla.
int main()
{
    int num1, num2, suma;
    scanf ("%i", &num1);
    scanf ("%i", &num2);
    suma = num1+num2;
    printf (" la suma es  : %i",suma );
    return 0;
}

