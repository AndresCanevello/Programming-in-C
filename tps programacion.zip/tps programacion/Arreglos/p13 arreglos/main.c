#include <stdio.h>
#include <stdlib.h>
//Dado el vector {1,5,6,7,8} escribir un programa que genere otro
//vector con la suma del contenido de todo los elementos anteriores al �ndice actual: {1,6,12,19,27}.
int main()
{
    int arreglo[10];
      int vectoraux[10];
    int vali2 = cargarArreglo (arreglo, 10);
    mostrarArreglo (arreglo, vali2);
    arregloSumatorio (arreglo, vectoraux, vali2);
    mostrarArreglo (vectoraux, vali2);
    return 0;
}
void arregloSumatorio (int arreglo[],int vectoraux[], int vali2)
{
    int i=0;
    int acumulador=0;

    while (i<vali2)
    {
        acumulador =  arreglo[i] + acumulador;
        vectoraux[i] = acumulador;
        i++;
    }
}
void mostrarArreglo (int arreglo[], int vali2)
{
    int i=0;
    while (i<vali2)
    {
        printf ("Su arreglo en posicion [%i] es :  %i\n",i , arreglo[i]);
        i++;
    }
}
int cargarArreglo (int arreglo[], int dim)
{
    int i=0;
    char inicio='s';
    while (i<dim&&inicio=='s')
    {
        printf ("Ingrese en su arreglo en la posicion %i :  \n", i);
        scanf ("%i", &arreglo[i]);
        printf ("Desea cargar otro elemento? S/N  : ");
        fflush (stdin);
        scanf("%c", &inicio);
        i++;
   }
   return i;
}
