#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arreglo[10];
    int validos= cargarArreglo(arreglo, 10);
    int elemento;
    mostrarArreglo (arreglo, validos);
    ordenamientoXins (arreglo, validos);
    mostrarArreglo (arreglo, validos);


    return 0;
}
void ordenamientoXins (int arreglo[], int vali2)
{
    int i=0;
    while (i<vali2-1)
    {
        insertarElement (arreglo, i, arreglo[i+1] );
        i++;
    }
}
void insertarElement (int arreglo[], int vali2, int elemento)
{
    int i = vali2 ;
    while (i>=0 && arreglo[i]>elemento)
    {
        arreglo[i+1] = arreglo[i];
        i--;
    }
    arreglo[i+1] = elemento;
    //(*vali2)++;
}
void mostrarArreglo (int arreglo[], int vali2)
{
    int i=0;
    while (i<vali2)
    {
        printf ("Su arreglo en posicion [%i] es :  %i\n", i, arreglo[i]);
        i++;
    }
}
int cargarArreglo (int arreglo[], int dim)
{
    int i=0;
    char continuar='s';
    while (i<dim&&continuar=='s')
    {
        printf ("ingrese su arreglo en posicion [%i] :  \n",i);
        scanf("%i", &arreglo[i]);
        printf ("desea ingresar otro elemento? S/N :  \n");
        fflush(stdin);
        scanf ("%c", &continuar);
        i++;
    }
    return i;
}
 /* printf("Ingrese el elemento a insertar :  \n");
    scanf("%i",&elemento);
    insertarElement (arreglo, &validos, elemento);
    mostrarArreglo (arreglo, validos);*/

