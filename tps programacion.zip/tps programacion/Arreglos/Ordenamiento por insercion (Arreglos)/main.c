#include <stdio.h>
#include <stdlib.h>
void ordenamientoXinsercionArreglo (int arreglo[], int vali2);
void insertar (int arreglo[],int vali2, int dato );
void mostrarArreglo (int arreglo[], int vali2);
int main()
{
    int arreglo[10]= {4,8,1,3,10,8};

    ordenamientoXinsercionArreglo (arreglo,6);
    mostrarArreglo (arreglo, 6);
    return 0;
}



void







void mostrarArreglo (int arreglo[], int vali2)
{
    int i=0;
    for ( i=0; i<vali2; i++)
    {
        printf ("Su arreglo en la posicion %i es : %i\n\n",i, arreglo[i] );
    }
}
void ordenamientoXinsercionArreglo (int arreglo[], int vali2)
{
    int i=0;
    while (i<vali2-1)
    {
        insertar (arreglo, i, arreglo[i+1]);
        i++;

    }
}
void insertar (int arreglo[],int vali2, int dato )
{
    int aux;
    int i = vali2;
    while (i>=0 && dato< arreglo[i])
    {
        arreglo[i+1]= arreglo[i];
        i--;
    }
    while (dato>arreglo[i])
    {
        arreglo
    }
    arreglo[i+1]= dato;
}
