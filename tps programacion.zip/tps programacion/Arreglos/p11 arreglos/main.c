#include <stdio.h>
#include <stdlib.h>
void insertarElement (int arreglo[], int vali, int elemento);
int cargarArreglo (int arreglo[], int dimension);
void mostrarArray (int arreglo[], int vali2);
void ordenamientoXinsercion (int arreglo[],int vali2);
int main()
{
    int array[10];
    int validos = cargarArreglo (array, 10);
    int elemento;
    mostrarArray (array, validos);
    ordenamientoXinsercion (array, validos);
    mostrarArray (array, validos);

    return 0;
}
void ordenamientoXinsercion (int arreglo[],int vali2)
{

    int elemento = arreglo[i+1];
    int i=vali2-1;
    while (i<vali2)
    {
        insertarElement (arreglo, vali2,elemento );
        i++;
    }
}
void insertarElement (int arreglo[], int vali, int elemento)
{   int i = vali;
    while ( (i >= 0) && ( arreglo[i] >= elemento ) )
    {
        arreglo [i+1] = arreglo [i];
        i--;
    }
    arreglo [i+1] = elemento;

}
void mostrarArray (int arreglo[], int vali2)
{
    int i=0;
    while (i<vali2)
    {
        printf ("Su arreglo en la posicion [%i] es :  %i\n",i , arreglo[i]);
        i++;
    }
}
int cargarArreglo (int arreglo[], int dimension)
{
    int i=0;
    char inicio='s';
    while (i<dimension&&inicio=='s'){
    printf("Ingrese en la posicion [%i] :  \n",i );
    scanf("%i", &arreglo[i]);
    printf ("Desea cargar otro dato? S/N :  \n");
    fflush(stdin);
    scanf("%c", &inicio);
    i++;
    }
    return i;
}
