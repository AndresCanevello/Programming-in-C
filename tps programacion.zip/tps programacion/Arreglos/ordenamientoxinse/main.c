#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arreglo[10];
    int validos = cargarArreglo(arreglo, 10);
    int menor;
    mostrarArreglo (arreglo, validos);
    ordenamientoXseleccion (arreglo, validos);
    mostrarArreglo (arreglo, validos);
    return 0;
}
int encontarMenor (int arreglo[], int vali2)
{
    int i=0;
    int menor = vali2-1;
    while (i<vali2)
    {
        if (arreglo[menor]<arreglo[i])
        {
            i++;
        }
        else {menor = i;
        i++;}
    }
    return menor;
}
void ordenamientoXseleccion (int arreglo[], int vali2)
{
    int i=0;
    int menor;
    int aux;
    while (i<vali2)
    {
        menor = encontarMenor (arreglo, i);
        aux = arreglo [menor];
        arreglo [menor] = arreglo[i];
        arreglo[i] = aux;
        i++;
    }
}

void ordenamientXinser (int arreglo[], int vali2)
{
    int i=0;
    while (i<vali2)
    {
        insertarElemento (arreglo, i, arreglo[i+1]);
        i++;
    }
}
void insertarElemento (int arreglo[], int vali2, int elemento)
{
    int i= vali2;
    while (i>=0&&arreglo[i]>elemento)
    {
        arreglo[i+1]=arreglo[i];
        i--;
    }
    arreglo [i+1] = elemento;
}
void mostrarArreglo (int arreglo[], int vali2)
{
    int i=0;
    while (i<vali2)
    {
        printf ("Su arreglo en posicion [%i] es :  %i\n", i, arreglo[i]);
        i++;
    }
}
int cargarArreglo (int arreglo[], int dim)
{
    int i=0;
    char continuar='s';
    while (i<dim && continuar=='s')
    {
        printf ("Ingrese su dato en la posicion [%i] :  \n", i);
        scanf("%i", &arreglo[i]);
        printf("Desea ingresar otro valor ? S/N :  \n");
        fflush(stdin);
        scanf("%c", &continuar);
        i++;
    }
    return i;
}
