#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num1= 8;
    int *num2= &num1;
    //funcion (&num1, &num2);
    printf ("%i %i %i %i", num2, num1, *num2, &num2);
    return 0;
}
//void funcion (int *num1, int *num2)
/*
    int aux;
    aux =15;
    *num1 = * num2;
    *num2 = aux;

}*/
