#include <stdio.h>
#include <stdlib.h>
#include <string.h>
const int fila=3;
const int columa=3;
void insertarNombre (char nombres[][columa], char nombre[], int vali2);
int determinanteDOS (int matri[][columa], int dim);
int sumarPosicionesPares(int Matriz[fila][columa]);
void persistencia(int A[], char B[], int validos);
void muestrarchi (char nombre[]);
void muestrarchiB (char nombre[]);
#define archivoa 'archivoA'
#define archivob 'archivoB'
int main()
{
    //srand(time(NULL));
    //cargaMatri(nombre, fila);
    //mostraMatri(nombre, fila);
    //int determinante = determinanteDOS (nombre, fila);
    //printf ("Determinante es: %i\n", determinante);
    //inversa (nombre, fila);
    //int matri2x5[2][5];
    //int matriaux[2][5];
    //cargaMatri2x5 (matri2x5, 2);
    //mostraMatri (cargaMatri2x5, 2);
    //multiplicacion (nombre, cargaMatri2x5, matriaux);
    //mostraMatri(matriaux, 2);
   // int resultado = sumarPosicionesPares(nombre);
   // printf ("El resultado es: %i\n", resultado);
   int A[5] = {2,3,4,5,6};
   char B[] = {'c', 'h','z','d','a'};
   int validos = 5;
   persistencia (A,B,validos);
    muestrarchi(archivoa);
    muestrarchiB (archivob);
    return 0;
}
void muestrarchiB (char nombre[])
{
    FILE * archi = fopen ("ArchivoB", "rb");
    char arreglito;
    if (archi!=NULL)
    {
        while (!feof(archi))
        {
            fread(&arreglito, sizeof(char),1,archi);
            if(!feof(archi))
            {
                printf ("Archivo B: %c\n",arreglito);
            }
        }
    }
}
void muestrarchi (char nombre[])
{
    FILE * archi = fopen ("archivoA", "rb");
    int arreglito=0;
    if (archi!=NULL)
    {
        while (!feof(archi))
        {
            fread(&arreglito, sizeof(int),1,archi);
            if(!feof(archi))
            {
                printf ("Archivo A: %i\n",arreglito);
            }
        }
    }
}
void persistencia(int A[], char B[], int validos)
{

    FILE * archi = fopen ("archivoA", "ab");
    FILE *archidos = fopen ("archivoB", "ab");

    if (archi !=NULL)
    {
        int i=0;
        while (i<validos)
        {
            fwrite (&A[i], sizeof(int),1,archi);
            i++;
        }
        fclose(archi);
    }
    else
    {
        printf("Error al abrir el archivo");
    }

    if (archidos !=NULL)
    {
        int f=0;
        while (f<validos)
        {
            fwrite (&B[f], sizeof(char),1,archidos);
            f++;
        }
        fclose(archidos);
    }
    else
    {
        printf("Error al abrir el archivo");
    }
}
    int sumarPosicionesPares(int Matriz[fila][columa])

    {

        int i=0;

        int s=0;

        int acumulador =0;

        for (s=0; s<fila ; s++)

            for (i=0; i<columa ; i++)

            {

                if ( (i+s)% 2 == 0)

                {

                    acumulador += Matriz[s][i];

                }

            }

        return acumulador;
    }
//Hacer una funci�n que multiplique una matriz de 2x2 por una matriz de 2x5.
    void multiplicacion (int matri[][columa], int motri[][5],int matriAux[][5];)
    {
        int i=0, j=0, k=0;
        int Elemento=0;
        for(i=0; i<fila; i++)
        {
            for(k=0; k<5; k++)
            {
                Elemento=0;

                for(j=0; j<columa; j++)
                {
                    //       Elemento = Elemento + (motri[i][j] * matriAux[j][k]);
//                NuevaMat[i][k] = Elemento;
                }
            }
        }

    }
    /*matriAux[0][0] = (matri[i][i]*motri[0][0])+(matri[0][1]*motri[1][0]);
    matriAux[0][1] = (matri[i][i]*motri[0][0])+(matri[0][1]*motri[1][0]);*/
    void inversa (int matri[][columa], int dim)
    {
        int determinante = determinanteDOS(matri, fila);
        if (determinante!=0)
        {
            printf ("Su matriz tiene inversa.");
        }
        else
        {
            printf ("Su matriz no tiene inversa.");
        }
    }
    int determinanteDOS (int matri[][columa], int dim)
    {
        int determinante = ((matri[0][0])*(matri[1][1]))-((matri[0][1]*matri[1][0]));

        return determinante;
    }
    void mostraMatri(int matri[][columa], int dim)
    {
        for (int i=0; i<dim ; i++)
        {
            for(int j=0; j<columa ; j++)
                printf ("%d ", matri[i][j]);
            printf("\n");
        }
    }
    void cargaMatri2x5 (int matri[][5], int dim)
    {
        for (int i=0; i<dim ; i++)
            for(int j=0; j<5 ; j++)
                matri[i][j] = rand()%5+1;

    }
    void cargaMatri (int matri[][columa], int dim)
    {
        for (int i=0; i<dim ; i++)
            for(int j=0; j<columa ; j++)
                matri[i][j] = rand()%5+1;

    }
    int cargaNombre (char nombre[][columa], int dim)
    {
        int i=0;
        char inicio='s';
        while (inicio=='s' && i< dim)
        {
            printf ("Carge su array de nombr: \n");
            fflush(stdin);
            scanf("%s", &nombre[i]);
            printf ("Desea cargar otro elemento? S/N:\n");
            fflush(stdin);
            scanf("%c", &inicio);
            i++;
        }
        return i;
    }
    void mostrarArray (char nombre[][columa], int vali2)
    {
        int i=0;
        while (i<vali2)
        {
            printf ("Su arreglo en pos |%i| es: %s\n",i, nombre[i]);
            i++;
        }
    }
    void ordenInser (char nombre[][columa], int vali2)
    {
        int i=0;
        char aux[fila];
        while (i<vali2-1)
        {
            strcpy (aux, nombre[i+1]);
            insertarNombre (nombre, aux, i);
            i++;
        }
    }
    void insertarNombre (char nombres[][columa], char nombre[fila], int vali2)
    {
        int i=vali2;
        while (i>=0 && strcmp(nombres[i],nombre)>0)
        {
            strcpy (nombres[i+1], nombres[i]);

            i--;
        }
        strcpy(nombres[i+1],nombre);
    }
