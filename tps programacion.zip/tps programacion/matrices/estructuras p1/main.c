#include <stdio.h>
#include <stdlib.h>
#include <string.h>
    typedef struct{
        int matricula;
        char nombre[30];
        char genero;
    } Alumno;
void ordeXselec (Alumno n1[], int vali2);
int buscarMenor (Alumno n1[], int vali2, int ultPos);
void insertarAluOrdeXmatri (Alumno n1[], int vali2, Alumno andru[]);
void ordenXinser (Alumno n1[], int vali2);
void insertarAlu (Alumno n1[], int vali2, Alumno andru);
int retornoAlu (Alumno n1[], int vali2, char genero);
int main()
{
    Alumno n1[30];
    int vali2;
    cargaAlum (n1,30, &vali2);

  //  int datoLegajo;
    //printf ("Ingrese su legajo a buscar:\n");
   // scanf("%d", &datoLegajo);
   // ordeXselec (n1, vali2);
    //muestraAlu (n1, vali2);
    //char buscaGenero;
    //printf ("Ingrese el genero a buscar:\n");
    //fflush(stdin);
    //scanf("%c", &buscaGenero);
    //mostrarGenero(n1, vali2, buscaGenero);
    /*Alumno n2[30];
    int vali2X2;
    printf ("Ingrese los datos a insertar en este arreglo ordenado x selec: \n");
    cargaAlum (n2,3, &vali2X2);
    insertarAlu (n1, vali2, n2);
    vali2 ++;*/
    muestraAlu (n1, vali2);
    /*ordenXinser (n1, vali2);
    muestraAlu (n1, vali2);*/
    char generacion;
    printf ("Ingrese el genero que desea saber la cantidad:\n");
    fflush(stdin);
    scanf("%c", &generacion);
    int cantAlum = retornoAlu (n1, vali2, generacion);
    printf ("Cantidad de alumnos %c es: %d",generacion, cantAlum);
    return 0;
}
int retornoAlu (Alumno n1[], int vali2, char genero)
{
    int i=0;
    int hombre=0;
    while (i<vali2)
    {
        if (n1[i].genero == genero)
        {
            hombre++;
        }
        i++;
    }
    return hombre;
}
void ordenXinser (Alumno n1[], int vali2)
{
    int i=0;
    while (i<vali2-1)
    {
        insertarAlu (n1, i, n1[i+1]);
        i++;
    }
}
void insertarAlu (Alumno n1[], int vali2, Alumno andru)
{
    int i=vali2;
    while (i>=0 && strcmp(n1[i].nombre,andru.nombre)>0)
    {
        n1[i+1].matricula = n1[i].matricula;
        n1[i+1].genero= n1[i].genero;
        strcpy(n1[i+1].nombre, n1[i].nombre);
        i--;
    }
    n1[i+1].matricula = andru.matricula;
    n1[i+1].genero=andru.genero;
    strcpy(n1[i+1].nombre,andru.nombre);
}
void insertarAluOrdeXmatri (Alumno n1[], int vali2, Alumno andru[])
{
    int i=vali2-1;
    while (i>=0 && n1[i].matricula>andru[0].matricula )
    {
        n1[i+1].matricula = n1[i].matricula;
        n1[i+1].genero= n1[i].genero;
        strcpy(n1[i+1].nombre, n1[i].nombre);
        i--;
    }
    n1[i+1].matricula = andru[0].matricula;
    n1[i+1].genero=andru[0].genero;
    strcpy(n1[i+1].nombre,andru[0].nombre);
}
void mostrarGenero (Alumno n1[], int vali2, char genero)
{
    int i=0;
    if (genero == 'm')
        printf ("Estudiantes hombres:\n");
    else if (genero =='f')
        printf ("Estudiantes mujeres:\n");
    while (i<vali2)
    {
        if (n1[i].genero == genero)
        {
        printf ("Matricula: %d\n", n1[i].matricula);
        printf ("   Nombre: %s\n", n1[i].nombre);
        printf ("   Genero: %c\n", n1[i].genero);
        printf ("------------------------------\n");
        }
        else if (n1[i].genero == genero){
        printf ("Matricula: %d\n", n1[i].matricula);
        printf ("   Nombre: %s\n", n1[i].nombre);
        printf ("   Genero: %c\n", n1[i].genero);
        printf ("------------------------------\n");
        }
        i++;
    }
}
void ordeXselec (Alumno n1[], int vali2)
{
    int i=0;
    int menor=0;
    int aux;
    char auxGene;
    char auxNombre[30];
    while (i<vali2)
    {
        menor = buscarMenor (n1, vali2, i);

        aux = n1[i].matricula;
        n1[i].matricula = n1[menor].matricula;
        n1[menor].matricula = aux;

        strcpy (auxNombre,n1[i].nombre);
        strcpy (n1[i].nombre, n1[menor].nombre);
        strcpy (n1[menor].nombre, auxNombre);

        auxGene =n1[i].genero;
        n1[i].genero = n1[menor].genero;
        n1[menor].genero = auxGene;
        i++;
    }
}
int buscarMenor (Alumno n1[], int vali2, int ultPos)
{
    int i=ultPos;
    int posMenor=ultPos;
    while (i<vali2)
    {
        if (n1[posMenor].matricula>n1[i].matricula)
        {
            posMenor = i;
        }
        i++;
    }
    return posMenor;
}
int mostrarLegajo (Alumno n1[], int vali2, int legajo)
{
    int i=0;
    while (i<vali2)
    {
        if (n1[i].matricula==legajo)
        {
        printf ("Su matricula se ha encontrado.\n");
        printf ("Matricula: %d\n", n1[i].matricula);
        printf ("   Nombre: %s\n", n1[i].nombre);
        printf ("   Genero: %c\n", n1[i].genero);
        printf ("------------------------------\n");
        return i;
        }
        i++;
    }
    printf ("Su legajo no se encuentra en la base de datos.");
    return i;
}
void muestraAlu(Alumno n1[], int vali2)
{
    int i=0;
    while (i<vali2)
    {
        printf ("Alumno n�%d.\n", i);
        printf ("Matricula: %d\n", n1[i].matricula);
        printf ("   Nombre: %s\n", n1[i].nombre);
        printf ("   Genero: %c\n", n1[i].genero);
        printf ("------------------------------\n");
        i++;
    }
}
void cargaAlum (Alumno n1[], int dim, int *i )
{
    char inicio='s';
    while (*i < dim && inicio=='s')
    {
        printf ("Ingrese su matricula:\n");
        scanf("%d", &n1[*i].matricula);
        printf ("Ingrese el nombre correspondiente a matricula n�%i:\n",n1[*i].matricula);
        fflush(stdin);
        scanf("%s", n1[*i].nombre);
        printf ("Ingrese el genero correspondiente al nombre %s:\n", n1[*i].nombre);
        fflush(stdin);
        scanf("%c", &n1[*i].genero);
        printf ("Desea ingresar otro alumno? S/N:\n");
        fflush(stdin);
        scanf("%c", &inicio);
        *(i) +=1;
    }
}
