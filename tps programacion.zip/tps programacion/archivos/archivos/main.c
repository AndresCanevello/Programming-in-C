#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pila.h"
typedef struct
{
    int legajo;
    char nombreYapellido [30];
    int edad;
    int anio;
} Alumno;
int retornoCantida(char edad[]);
void cargaArchi (char edad[]);
void muestraArchi (char edad[]);
void cargaAlumnos (char alumnos[]);
void mostrarRegistro (char alumnos[]);
void pasarPilaMayores (char nombre[], Pila*);
void mostrarNombre (char nombre[], int dato, int dato2); //punto 9
int retornoAluANIO (char Alumno[], int dato);
int main()
{
    int edad[20];
    Pila pepito;
    inicpila(&pepito);
  // cargaAlumnos(edad);
    mostrarRegistro (edad);
    //printf (" ASD\N ");
    int retorno= retornoCantida(edad);
    printf ("LOS REGISTREO SON : %i",retorno);
    /*PUNTO 7pasarPilaMayores (edad, &pepito);
    mostrar (&pepito); PUNTO 7*/
    /*PUNTO 8int dato=0;
    printf ("Ingrese su edad a saber: \n");
    scanf("%i", &dato);
    int result = contarAluXedad (edad, dato);
    printf ("El resultado es: %d", result); PUNTO 8*/
    /*PUNTO9int dato, dato2;
    printf ("Ingrese el rango de edades que desea saber(teniendo en cuenta que el primer dato debe ser mayor que el 2do):\n");
    scanf("%d",&dato);
    scanf("%d",&dato2);
    mostrarNombre(edad, dato, dato2);PUNTO 9*/
    //PUNTO 10mostrarMayores(edad);
    /*PUNTO11int edadDato;
    printf ("Ingrese su anio a saber: \n");
    scanf("%i",&edadDato);
    int resultEdad =retornoAluANIO(edad, edadDato);
    printf ("Los alumnos de ese anio son: %d", resultEdad);PUNTO11*/

    copiarEnArchi(edad, edad);
    mostrarRegistro(edad);
    return 0;
}
void copiarEnArchi (char gente[], Alumno pepe[]) //PUNTO 12 PART1
{
    FILE *archi;
    archi = fopen ("piter", "wb");
    if (archi!=NULL)
    {
        while (!feof(archi))
        {
            if(!feof (archi))
            {
               fwrite(&pepe,sizeof(Alumno),1,archi);
            }

        }
         fclose (archi);
    }
}
int retornoAluANIO (char gente[], int dato) //punto11
{
    FILE * archi;
    archi = fopen("alumnos","rb");
    Alumno X;
    int i=0;
    if (archi != NULL)
    {
        while (!feof(archi))
        {
            fread (&X,sizeof(Alumno),1,archi);
            if(!feof(archi))
            {
                if (X.anio == dato)
                {
                    i++;
                }
            }
        }
        fclose(archi);
    }
    return i;
}
void mostrarMayores(char nombre[]) //PUNTO 10
{
    FILE * archi;
    archi = fopen("alumnos", "rb");
    Alumno X;
    if (archi != NULL)
    {
        while (!feof (archi))
        {
            fread(&X,sizeof(Alumno),1,archi);
            if (!feof(archi))
            {
                if (X.edad>=18)
                {
                    printf ("|%s|\n",X.nombreYapellido);
                }
            }
        }
        fclose(archi);
    }
}
void mostrarNombre (char nombre[], int dato, int dato2) //punto 9
{
    FILE * archi;
    Alumno J;
    archi = fopen("alumnos", "rb");
    if (archi != NULL)
    {
        while (!feof (archi))
        {
            fread (&J,sizeof(Alumno),1,archi);
            if (!feof (archi))
            {
                if (dato<J.edad && J.edad<dato2)
                {
                    printf (" |  %s  | ", J.nombreYapellido);
                }
            }
        }
        fclose(archi);
    }
}
int contarAluXedad (char nombre[], int dato) //punto 8
{
    FILE * ARCHI;
    ARCHI  = fopen("alumnos", "rb");
    Alumno A;
    int i=0;
    if (ARCHI != NULL)
    {
        while (!feof (ARCHI))
        {
            fread (&A, sizeof(Alumno),1,ARCHI);
            if (!feof (ARCHI))
            {
                if (A.edad>dato)
                {
                    i++;
                }
            }
        }
        fclose(ARCHI);
    }
    return i;
}
void pasarPilaMayores (char nombre[], Pila * pepito) //PUNTO 7
{
    Alumno H;
    FILE * archi = fopen("alumnos", "rb");
    if (archi !=NULL)
    {
        while (!feof (archi))
        {
            fread(&H,sizeof(Alumno),1,archi);
            if (!feof (archi))
            {
                if (H.edad >= 18)
                {
                    apilar (pepito, H.legajo);
                }
            }
        }
    fclose(archi);
    }
}

void cargarAluAB (char nombre[], char dato[]) //punto 6 AGREGAR DE A UN ARCHIVO AL FINAL.
{
    FILE * archi;
    Alumno huguito;
    archi = fopen (dato[0], "ab");
    if (archi != NULL)
    {
        printf ("Ingrse nombre y apellido:\n");
        fflush(stdin);
        scanf("%s", &huguito.nombreYapellido);
        printf ("Ingrese numero de legajo:\n");
        fflush(stdin);
        scanf("%i", &huguito.legajo);
        printf ("Ingrese la edad correspondiente:\n");
        fflush(stdin);
        scanf("%i", &huguito.edad);
        printf ("Por ultimo ingrese el anio:\n");
        fflush(stdin);
        scanf("%i", &huguito.anio);
        fwrite(&huguito,sizeof(Alumno),1,archi);
        fclose (archi);
    }
}
void mostrarRegistro (char alumnos[]) // punto 5
{
    FILE *archi;
    Alumno jose;
    int i=0;
    archi = fopen ("alumnos", "rb");
    if (archi != NULL)
    {
        while (!feof (archi))
        {
            fread(&jose, sizeof(Alumno),1,archi);
            if (!feof (archi))
            {
                puts  ("---------------------------------------------");
                printf ("Nombre y apellido: %s\n", jose.nombreYapellido);
                printf ("             Edad: %i\n", jose.edad);
                printf ("           Legajo: %i\n", jose.legajo);
                printf ("              A�o: %i\n", jose.anio);
                puts  ("---------------------------------------------");
            }
        }
        fclose(archi);
    }
}
void cargaAlumnos (char alumnos[]) //punto 4
{
    FILE * archi;
    Alumno huguito;
    int i=0;
    char inicio='s';
    archi = fopen ("alumnos", "ab");
    if (archi != NULL)
    {
        while (i<5 && inicio=='s')
        {
            printf ("Ingrse nombre y apellido:\n");
            fflush(stdin);
            scanf("%s", &huguito.nombreYapellido);
            printf ("Ingrese numero de legajo:\n");
            fflush(stdin);
            scanf("%i", &huguito.legajo);
            printf ("Ingrese la edad correspondiente:\n");
            fflush(stdin);
            scanf("%i", &huguito.edad);
            printf ("Por ultimo ingrese el anio:\n");
            fflush(stdin);
            scanf("%i", &huguito.anio);
            fwrite(&huguito,sizeof(Alumno),1,archi);
            printf ("Desea cargar otro usuario?S/N:\n");
            fflush(stdin);
            scanf("%c", &inicio);
            i++;
        }
        fclose (archi);
    }
}
int retornoCantida(char edad[])
{
    FILE * archivito;
    archivito = fopen("alumnos", "rb");
    Alumno aux2;
    int i=0;
    if (fopen!=NULL)
    {
        while (!feof (archivito))
        {
            fread(&aux2, sizeof(Alumno),1,archivito);
            if (!feof (archivito))
            {
                i++;
                printf ("%i",i);
            }
        }
        fclose(archivito);
    }
    return i;
}
void cargaArchi (char edad[]) //punto 1
{
    FILE *archi;
    archi = fopen ("edad", "ab" );
    if (archi != NULL)
    {
        printf ("Ingrese su edad: \n");
        fflush(stdin);
        scanf("%i", &edad);
        fwrite (&edad, sizeof(int),1,archi);
        fclose(archi);
    }
}
void muestraArchi (char edad[]) //punto 2
{
    FILE *archi;
    int edadese;
    archi = fopen ("roman", "rb");
    if (archi != NULL)
    {
        fread(&edadese, sizeof(int),1,archi);
        printf ("Su edad es: %i", edadese);
        fclose(archi);
    }
}

