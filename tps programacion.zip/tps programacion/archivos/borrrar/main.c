#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int ID;
    int TipoNave;
    int CantVuelos;
    int HorasVuelo;
    int Estado;
} stNaves;
int main()
{
    printf("Hello world!\n");
    cargaNave("asdf");
    muestraNave ("asdf");
    return 0;
}
void cargaNave (char nombre [])
{
    int j=200;
    char continuar ='s';
    stNaves aux;
    FILE*archivo=fopen(nombre,"wb");
    if(archivo!=NULL)
    {
        while(continuar =='s')
        {
            aux.ID=j;
            j++;
            printf("ID %d",aux.ID);
            printf("Ingrese el tipo de nave\n");
            printf("1/falcon 9\n2/star ship\n3/falcon heavy ");
            scanf("%d",&aux.TipoNave);
            printf("Ingrese cantidad de vuelos ");
            scanf("%d",&aux.CantVuelos);
            printf("Ingrese las horas de vuelo ");
            scanf("%d",&aux.HorasVuelo);
            printf("ingrese el estado de la nave ");
            printf("0:mantenimiento\n1:Listo para uso\n2:Actual mente en mision\n3:De baja ");
            scanf("%d",&aux.Estado);
            fwrite(&aux,sizeof(stNaves),1,archivo);
            printf("Desea continuar (s\n)");
            fflush(stdin);
            scanf("%c",&continuar);
        }
        fclose(archivo);
    }
}
void muestraNave (char nombre[])
{
    stNaves aux;
    FILE * archi = fopen (nombre, "rb");
    if (archi!=NULL)
    {
        while (!feof (archi))
        {
             int ID;
    int TipoNave;
    int CantVuelos;
    int HorasVuelo;
    int Estado;
            fread (&aux, sizeof (stNaves),1,archi);
            if (!feof(archi))
            {
                puts ("---------------------------------------");
                printf ("ID nave: |%i|\n", aux.ID);
                printf ("Tipo de nave: %i\n", aux.TipoNave);
                printf ("Cantidad de vuelos: %i\n",aux.CantVuelos);
                printf ("Cantidad de horas en vuelo: %i\n", aux.HorasVuelo);
                printf ("Estado de la nave: %i\n", aux.Estado);
            }
        }
    }

}
