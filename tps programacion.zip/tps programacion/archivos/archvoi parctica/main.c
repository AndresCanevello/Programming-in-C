#include <stdio.h>
#include <stdlib.h>
#define archivito "ArchivitoB"
typedef struct
{
    char nombre[30];
    int edad;
}stAlum;
void cargaArchi ();
void muestraarchi ();

int main()
{
//cargaArchi(archivito);
 //muestraarchi(archivito);
 stAlum juan[10];
 int i=0;
cargaStruct(juan, 10, &i);
 muestraStruct(juan, i);
 pasarStructArchi (juan, i);
 muestraarchi(archivito);
    return 0;
}
void pasarStructArchi (stAlum pepe[], int vali2)
{
    FILE *archi = fopen (archivito, "ab");
    int i=0;
    if (archi!=NULL)
    {
        while (i<vali2)
        {
            fwrite (&pepe[i],sizeof(stAlum),1,archi);
            i++;
        }
        fclose (archi);
    }
}
void muestraStruct (stAlum Pepe[], int vali2)
{
    int i=0;
    while (i<vali2)
    {
        printf ("Estructura n%i:\n",i);
        printf ("Nombre : %s\n",Pepe[i].nombre);
        printf ("  Edad : %i\n", Pepe[i].edad);
        i++;
    }
}
void cargaStruct (stAlum Juan[], int dim, int *i)
{
    char inicio='s';
    while (inicio=='s'&& *i<dim)
    {
        printf ("Ingrese su nombre en pos %i : \n",*i);
        fflush(stdin);
        scanf("%s", &Juan[*i].nombre);
        printf ("Ingrese la edad del nombre %s:\n",Juan[*i].nombre);
        scanf("%i", &Juan[*i].edad);
        printf("Desea cargar otro alumno? S/N:\n");
        fflush(stdin);
        scanf("%c",&inicio);
        *(i) += 1;
    }
}
void cargaArchi (char nombre[])
{
    stAlum Pepe;
    char inicio = 's';
    FILE * archi = fopen (nombre, "wb");
    if (archi!=NULL)
    {
        while (inicio == 's')
        {
            printf ("Ingrese su nombre a guardar en archi: \n");
            fflush(stdin);
            scanf("%s", &Pepe.nombre);
            printf ("Ingrese la edad de %s: \n", Pepe.nombre);
            scanf("%i", &Pepe.edad);
            printf ("Guardado, desea ingresar otro alu? S/N:\n");
            fflush(stdin);
            scanf("%c", &inicio);
            fwrite(&Pepe, sizeof(stAlum),1,archi);
        }
        fclose(archi);
    }
}
void muestraarchi (char nombre[])
{
    FILE * archivo;
    stAlum variable;
    int i=1;
    archivo = fopen(nombre, "rb");
    if (archivo != NULL)
    {
        while (!feof(archivo))
        {
            fread (&variable,sizeof(stAlum),1,archivo);
            if (!feof (archivo))
            {
                printf ("Archivo n�:%i\n",i);
                printf ("Nombre: %s\n",variable.nombre);
                printf ("  Edad: %i\n", variable.edad);
                i++;
            }
        }
        fclose(archivo);
    }
}
