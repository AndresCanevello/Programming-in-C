#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int legajo;
    char nombreYapellido [30];
    int edad;
} alumno;
void ella (char nombre[]);
void muestraArchi(char nombre[]);
void cargafinal(char nombnre[]);
int retornaregistros (char nom[]);
int main()
{
     system("COLOR C0");
    alumno persona[30];
   // muestraArchi(persona);
   // ella (persona);
//cargafinal(persona);
   int contador = retornaregistros (persona);
   printf("su cantiodad de registros es de %d ",contador);

   muestraArchi(persona);
    return 0;
}
void ella (char nombre[])
{
    alumno nom[30];
    FILE*archivos;
    archivos=fopen("nombre","rb");
    int i=0;
    char inicio='s';
    if(archivos!= NULL)
    {
        printf("su archivo ya existia previamente\n");
        fclose(archivos);
    }
    else
        printf("su archivo no exixstia\n ");

    archivos=fopen("nombre","wb");
    if(archivos != NULL)
    {
        while(i<5 && inicio=='s')
        {
            printf("ingrese el nombre del alumno: \n");
            fflush(stdin);
            scanf("%s", &nom[i].nombreYapellido);
            printf ("Ingrese la edad:\n");
            scanf("%i", &nom[i].edad);
            printf ("ingrese el legajo de su alumno: \n");
            scanf("%d",&nom[i].legajo);
            fwrite(&nom[i],sizeof(alumno),1,archivos);
            i++;
            printf ("cargas otro? S/N:\n");
            fflush(stdin);
            scanf("%c", &inicio);
        }
        fclose(archivos);
    }
}
void muestraArchi(char nombre[])
{
    FILE * archivo;
    archivo = fopen("nombre", "rb");
    alumno AUX;
    int cantidad=0;

    if (archivo!=NULL)
    {
        while (!feof(archivo))
        {
            fread(&AUX,sizeof(alumno),1,archivo);
            if (!feof (archivo))
            {
                puts("---------------------------------------------\n");
                printf ("Nombre: %s\n",AUX.nombreYapellido);
                printf ("  Edad: %i\n", AUX.edad);
                printf ("Legajo: %i\n",AUX.legajo);
                puts ("---------------------------------------------\n");
            }
        }
        fclose(archivo);
    }
}
void cargafinal(char nombnre[])
{
    alumno aux[30];
    char  inicio = 's';
    int i=0;
    FILE *archivo = fopen("nombre","ab");
    if(archivo!=NULL)
    {
        while(inicio=='s')
        {
            printf("ingrese el nombre a agregar ");
            fflush(stdin);
            scanf("%s",&aux[i].nombreYapellido);
            printf("ingrese la edad a agregarc ");
            scanf("%i"                                                                                                                                                                                      ,&aux[i].edad);
            printf("ingrese el legajo a agragar ");
            scanf("%d",&aux[i].legajo);
            printf("Ingrese s p�ra continuar ingresando ");
            fflush(stdin);
            scanf("%c",&inicio);

            fwrite(&aux[i],sizeof(alumno),1,archivo);
            i++;
     }
        fclose(archivo);
    }
}
int retornaregistros (char nom[])
{
    int contador =0;
    alumno nombresito[30];
    FILE*archivo=fopen("nombre","rb");
    if(archivo!=NULL)
    {
        fseek(archivo,0,SEEK_END);
        contador=ftell(archivo)/sizeof(alumno);
        fclose(archivo);

    }
return contador;
}
